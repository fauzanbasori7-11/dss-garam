<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RiwayatSimulasi extends Model
{
    use HasFactory;

    protected $fillable = [
        'judul_skenario',
        'parameter_sd',
        'hasil_proyeksi_sd',
        'hasil_electre',
        'rekomendasi_utama'
    ];

    protected $casts = [
        'parameter_sd' => 'array',
        'hasil_proyeksi_sd' => 'array',
        'hasil_electre' => 'array',
    ];
}
