<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PenilaianPakar extends Model
{
    use HasFactory;

    protected $fillable = ['nama_pakar', 'instansi', 'bobot_kriteria', 'catatan'];

    protected $casts = [
        'bobot_kriteria' => 'array',
    ];
}
