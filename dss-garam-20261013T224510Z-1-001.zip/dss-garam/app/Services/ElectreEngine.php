<?php

namespace App\Services;

class ElectreEngine
{
    protected array $alternatives = ['A1', 'A2', 'A3', 'A4'];
    protected array $criteria     = ['C1', 'C2', 'C3', 'C4', 'C5'];
    protected array $weights      = [0.25, 0.25, 0.20, 0.15, 0.15];

    public function __construct(array $alternatives = [], array $criteria = [], array $weights = [])
    {
        if (!empty($alternatives)) $this->alternatives = $alternatives;
        if (!empty($criteria)) $this->criteria = $criteria;
        if (!empty($weights)) $this->weights = $weights;
    }

    public function setWeights(array $weights): void
    {
        $this->weights = $weights;
    }

    public function setAlternatives(array $alternatives): void
    {
        $this->alternatives = $alternatives;
    }

    public function setCriteria(array $criteria): void
    {
        $this->criteria = $criteria;
    }

    /**
     * Langkah 1 & 2: Normalisasi dan Pembobotan Matriks
     */
    private function normalizeAndWeightMatrix(array $matrix, array $criteriaTypes, array $activeWeights): array
    {
        $normalizedWeighted = [];
        
        foreach ($this->criteria as $j => $criterion) {
            // Hitung bobot kriteria ini
            $w = $activeWeights[$criterion] ?? ($activeWeights[$j] ?? ($this->weights[$criterion] ?? ($this->weights[$j] ?? 0.2)));

            // Hitung akar jumlah kuadrat untuk kriteria j (pembagi)
            $sumSquares = 0;
            foreach ($this->alternatives as $alt) {
                $val = $matrix[$alt][$criterion] ?? 0;
                $sumSquares += pow($val, 2);
            }
            $denominator = sqrt($sumSquares);

            // Terapkan normalisasi dan kalikan dengan bobot
            foreach ($this->alternatives as $alt) {
                $val = $matrix[$alt][$criterion] ?? 0;
                $normalizedValue = $denominator > 0 ? ($val / $denominator) : 0;
                $normalizedWeighted[$alt][$criterion] = $normalizedValue * $w;
            }
        }
        
        return $normalizedWeighted;
    }

    /**
     * Langkah 3 & 4: Matriks Indeks Concordance dan Discordance
     */
    private function calculateIndices(array $vMatrix, array $criteriaTypes, array $activeWeights): array
    {
        $concordance = [];
        $discordance = [];

        foreach ($this->alternatives as $altK) {
            foreach ($this->alternatives as $altL) {
                if ($altK === $altL) {
                    $concordance[$altK][$altL] = 0;
                    $discordance[$altK][$altL] = 0;
                    continue;
                }

                $cIndex = 0;
                $dDiff = [];
                $allDiff = [];

                foreach ($this->criteria as $j => $c) {
                    $valK = $vMatrix[$altK][$c] ?? 0;
                    $valL = $vMatrix[$altL][$c] ?? 0;
                    $type = $criteriaTypes[$c] ?? 'benefit';
                    $w    = $activeWeights[$c] ?? ($activeWeights[$j] ?? 0.2);

                    $diff = abs($valK - $valL);
                    $allDiff[] = $diff;

                    // Syarat Concordance: Alternatif K lebih baik atau sama dengan L
                    $isKBetter = ($type === 'benefit') ? ($valK >= $valL) : ($valK <= $valL);

                    if ($isKBetter) {
                        $cIndex += $w;
                    } else {
                        $dDiff[] = $diff;
                    }
                }

                $concordance[$altK][$altL] = $cIndex;
                $maxDDiff = !empty($dDiff) ? max($dDiff) : 0;
                $maxAllDiff = !empty($allDiff) ? max($allDiff) : 0.00001;
                $discordance[$altK][$altL] = $maxAllDiff > 0 ? ($maxDDiff / $maxAllDiff) : 0;
            }
        }

        return ['concordance' => $concordance, 'discordance' => $discordance];
    }

    /**
     * Langkah 5 & 6: Threshold dan Matriks Dominasi (Outranking)
     */
    private function calculateOutranking(array $concordance, array $discordance): array
    {
        $n = count($this->alternatives);
        $pairCount = $n * ($n - 1);

        $sumC = 0;
        $sumD = 0;

        foreach ($this->alternatives as $k) {
            foreach ($this->alternatives as $l) {
                if ($k !== $l) {
                    $sumC += $concordance[$k][$l];
                    $sumD += $discordance[$k][$l];
                }
            }
        }

        $thresholdC = $pairCount > 0 ? ($sumC / $pairCount) : 0;
        $thresholdD = $pairCount > 0 ? ($sumD / $pairCount) : 0;

        $outrankingMatrix = [];
        $netScores = [];

        foreach ($this->alternatives as $alt) {
            $netScores[$alt] = 0;
        }

        foreach ($this->alternatives as $k) {
            foreach ($this->alternatives as $l) {
                if ($k === $l) {
                    $outrankingMatrix[$k][$l] = 0;
                    continue;
                }

                // Syarat Dominasi: C >= thresholdC DAN D <= thresholdD
                if ($concordance[$k][$l] >= $thresholdC && $discordance[$k][$l] <= $thresholdD) {
                    $outrankingMatrix[$k][$l] = 1;
                    $netScores[$k] += 1;
                    $netScores[$l] -= 1;
                } else {
                    $outrankingMatrix[$k][$l] = 0;
                }
            }
        }

        arsort($netScores);

        return [
            'ranking' => $netScores,
            'netScores' => $netScores,
            'outranking_matrix' => $outrankingMatrix,
            'thresholds' => ['c' => round($thresholdC, 4), 'd' => round($thresholdD, 4)]
        ];
    }

    /**
     * FUNGSI UTAMA yang dipanggil di Controller
     */
    public function evaluatePeriod(array $systemDynamicsOutput, array $criteriaTypes, array $weights = []): array
    {
        $activeWeights = !empty($weights) ? $weights : $this->weights;
        $vMatrix = $this->normalizeAndWeightMatrix($systemDynamicsOutput, $criteriaTypes, $activeWeights);
        $indices = $this->calculateIndices($vMatrix, $criteriaTypes, $activeWeights);
        return $this->calculateOutranking($indices['concordance'], $indices['discordance']);
    }
}
