<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\ElectreEngine;
use App\Models\Kriteria;
use App\Models\Alternatif;
use App\Models\PenilaianPakar;
use App\Models\RiwayatSimulasi;

class SimulationController extends Controller
{
    protected $electreEngine;

    public function __construct(ElectreEngine $electreEngine)
    {
        $this->electreEngine = $electreEngine;
    }

    /**
     * Dashboard Utama (Mengambil data master & riwayat simulasi terbaru dari DB)
     */
    public function index()
    {
        $kriterias = Kriteria::all();
        $alternatifs = Alternatif::where('aktif', true)->get();
        $latestSimulasi = RiwayatSimulasi::latest()->first();

        $topPriority = $latestSimulasi ? $latestSimulasi->rekomendasi_utama : ($alternatifs->first()->nama ?? 'Optimalisasi Buffer Stock');
        $riwayats = RiwayatSimulasi::latest()->take(5)->get();

        return view('dashboard', compact('kriterias', 'alternatifs', 'topPriority', 'latestSimulasi', 'riwayats'));
    }

    /**
     * Halaman System Dynamics
     */
    public function systemDynamics()
    {
        $kriterias = Kriteria::all();
        return view('system-dynamics', compact('kriterias'));
    }

    /**
     * Halaman Dynamic ELECTRE
     */
    public function dynamicElectre()
    {
        $latestSimulasi = RiwayatSimulasi::latest()->first();
        $alternatifs = Alternatif::where('aktif', true)->get();
        return view('dynamic-electre', compact('latestSimulasi', 'alternatifs'));
    }

    /**
     * Halaman Expert Judgment (Ambil kriteria & riwayat penilaian pakar dari DB)
     */
    public function expertJudgment()
    {
        $kriterias = Kriteria::all();
        $daftarPakar = PenilaianPakar::latest()->take(10)->get();
        
        return view('expert-judgment', compact('kriterias', 'daftarPakar'));
    }

    /**
     * Simpan Penilaian / Bobot dari Pakar ke Database MySQL
     */
    public function simpanPenilaian(Request $request)
    {
        $request->validate([
            'nama_pakar' => 'required|string|max:255',
            'instansi' => 'nullable|string|max:255',
            'bobot' => 'required|array',
            'catatan' => 'nullable|string'
        ]);

        $penilaian = PenilaianPakar::create([
            'nama_pakar' => $request->nama_pakar,
            'instansi' => $request->instansi ?? '-',
            'bobot_kriteria' => $request->bobot,
            'catatan' => $request->catatan ?? '-'
        ]);

        return response()->json([
            'status' => 'success',
            'message' => 'Penilaian pakar berhasil disimpan ke database!',
            'data' => $penilaian
        ]);
    }

    /**
     * Jalankan Simulasi Terintegrasi:
     * System Dynamics -> ELECTRE -> Simpan Hasil ke DB (RiwayatSimulasi)
     */
    public function jalankanSimulasi(Request $request)
    {
        $skenario = $request->input('skenario', 'Skenario Normal');
        $curahHujan = (float) $request->input('curah_hujan', 120);
        $kapasitasGudang = (float) $request->input('kapasitas_gudang', 50000);

        // 1. Ambil bobot kriteria (Gunakan rata-rata dari Pakar jika ada, atau bobot default kriteria)
        $kriterias = Kriteria::all();
        $weights = [];
        $criteriaTypes = [];

        $latestPakar = PenilaianPakar::latest()->first();
        foreach ($kriterias as $k) {
            $criteriaTypes[$k->kode] = $k->tipe;
            if ($latestPakar && isset($latestPakar->bobot_kriteria[$k->kode])) {
                $weights[$k->kode] = (float) $latestPakar->bobot_kriteria[$k->kode];
            } else {
                $weights[$k->kode] = (float) $k->bobot_default;
            }
        }

        // Normalisasi total bobot menjadi 1.0 jika belum pas
        $totalWeight = array_sum($weights) ?: 1;
        foreach ($weights as $key => $val) {
            $weights[$key] = round($val / $totalWeight, 4);
        }

        // 2. Simulasi Proyeksi System Dynamics (3 Periode: Q1, Q2, Q3)
        $factorIklim = max(0.5, 1 - ($curahHujan / 300));
        $proyeksiSD = [
            'Q1' => [
                'A1' => ['C1' => round(12000 * $factorIklim), 'C2' => 8500, 'C3' => 12.5, 'C4' => 85, 'C5' => 78],
                'A2' => ['C1' => round(11000 * $factorIklim), 'C2' => 8200, 'C3' => 9.0,  'C4' => 92, 'C5' => 70],
                'A3' => ['C1' => round(14500 * $factorIklim), 'C2' => 8700, 'C3' => 15.0, 'C4' => 80, 'C5' => 90],
                'A4' => ['C1' => round(10500 * $factorIklim), 'C2' => 8900, 'C3' => 8.5,  'C4' => 88, 'C5' => 75],
            ],
            'Q2' => [
                'A1' => ['C1' => round(15000 * $factorIklim), 'C2' => 8700, 'C3' => 14.0, 'C4' => 88, 'C5' => 80],
                'A2' => ['C1' => round(13500 * $factorIklim), 'C2' => 8400, 'C3' => 9.5,  'C4' => 95, 'C5' => 72],
                'A3' => ['C1' => round(18000 * $factorIklim), 'C2' => 9100, 'C3' => 16.5, 'C4' => 82, 'C5' => 92],
                'A4' => ['C1' => round(13000 * $factorIklim), 'C2' => 9000, 'C3' => 8.8,  'C4' => 89, 'C5' => 76],
            ],
            'Q3' => [
                'A1' => ['C1' => round(18000 * $factorIklim), 'C2' => 8900, 'C3' => 15.0, 'C4' => 90, 'C5' => 82],
                'A2' => ['C1' => round(15000 * $factorIklim), 'C2' => 8600, 'C3' => 10.0, 'C4' => 96, 'C5' => 74],
                'A3' => ['C1' => round(21000 * $factorIklim), 'C2' => 9400, 'C3' => 17.5, 'C4' => 85, 'C5' => 95],
                'A4' => ['C1' => round(14500 * $factorIklim), 'C2' => 9200, 'C3' => 9.0,  'C4' => 91, 'C5' => 78],
            ]
        ];

        // 3. Eksekusi ELECTRE II / Dynamic Outranking
        $electreResults = [];
        $netScores = [];

        foreach ($proyeksiSD as $periode => $matrix) {
            $res = $this->electreEngine->evaluatePeriod($matrix, $criteriaTypes, $weights);
            $electreResults[$periode] = $res;
            
            // Hitung net score akumulasi
            foreach ($res['netScores'] ?? [] as $altKey => $score) {
                $netScores[$altKey] = ($netScores[$altKey] ?? 0) + $score;
            }
        }

        // Urutkan alternatif berdasarkan Net Score tertinggi
        arsort($netScores);
        $topAltCode = array_key_first($netScores);

        $alternatifDb = Alternatif::where('kode', $topAltCode)->first();
        $rekomendasiNama = $alternatifDb ? $alternatifDb->nama : $topAltCode;

        // 4. Simpan ke Database (Tabel riwayat_simulasis)
        $simpanRiwayat = RiwayatSimulasi::create([
            'judul_skenario' => $skenario,
            'parameter_sd' => [
                'curah_hujan' => $curahHujan,
                'kapasitas_gudang' => $kapasitasGudang
            ],
            'hasil_proyeksi_sd' => $proyeksiSD,
            'hasil_electre' => [
                'period_evaluations' => $electreResults,
                'accumulated_scores' => $netScores,
                'weights_used' => $weights
            ],
            'rekomendasi_utama' => $rekomendasiNama
        ]);

        return response()->json([
            'status' => 'success',
            'message' => 'Simulasi berhasil dijalankan dan disimpan ke Database!',
            'data' => [
                'id_simulasi' => $simpanRiwayat->id,
                'rekomendasi' => $rekomendasiNama,
                'net_scores' => $netScores,
                'detail_electre' => $electreResults
            ]
        ]);
    }

    /**
     * Cetak / Ekspor Laporan Hasil Simulasi (HTML Printable & PDF View)
     */
    public function cetakLaporan($id = null)
    {
        $simulasi = $id ? RiwayatSimulasi::find($id) : RiwayatSimulasi::latest()->first();

        if (!$simulasi) {
            return redirect('/')->with('error', 'Belum ada riwayat simulasi untuk dicetak.');
        }

        $namaAlternatif = Alternatif::pluck('nama', 'kode')->toArray();

        return view('laporan-simulasi', compact('simulasi', 'namaAlternatif'));
    }
}

