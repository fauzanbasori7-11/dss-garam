<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DssGaramSeeder extends Seeder
{
    public function run(): void
    {
        // 1. Data Awal Kriteria
        DB::table('kriterias')->insert([
            [
                'kode' => 'C1',
                'nama' => 'Ketersediaan Stok Buffer (Ton)',
                'tipe' => 'benefit',
                'bobot_default' => 0.2500,
                'deskripsi' => 'Kemampuan menjaga kestabilan cadangan garam daerah',
                'created_at' => now(),
                'updated_at' => now()
            ],
            [
                'kode' => 'C2',
                'nama' => 'Stabilitas Harga Petani (Rp/Kg)',
                'tipe' => 'benefit',
                'bobot_default' => 0.2500,
                'deskripsi' => 'Tingkat penjagaan harga agar tidak anjlok saat panen raya',
                'created_at' => now(),
                'updated_at' => now()
            ],
            [
                'kode' => 'C3',
                'nama' => 'Biaya Anggaran Intervensi (Miliar Rp)',
                'tipe' => 'cost',
                'bobot_default' => 0.2000,
                'deskripsi' => 'Besaran biaya fiskal daerah yang dikeluarkan',
                'created_at' => now(),
                'updated_at' => now()
            ],
            [
                'kode' => 'C4',
                'nama' => 'Efisiensi Distribusi Antar Pulau',
                'tipe' => 'benefit',
                'bobot_default' => 0.1500,
                'deskripsi' => 'Kelancaran pasokan garam ke luar pulau Madura',
                'created_at' => now(),
                'updated_at' => now()
            ],
            [
                'kode' => 'C5',
                'nama' => 'Dampak Ketahanan Iklim',
                'tipe' => 'benefit',
                'bobot_default' => 0.1500,
                'deskripsi' => 'Resiliensi terhadap variabilitas cuaca ekstrem',
                'created_at' => now(),
                'updated_at' => now()
            ],
        ]);

        // 2. Data Awal Alternatif Kebijakan
        DB::table('alternatifs')->insert([
            [
                'kode' => 'A1',
                'nama' => 'Optimalisasi Penyerapan Buffer Stock BUMD',
                'deskripsi' => 'Pemerintah membeli kelebihan produksi untuk disimpan di gudang penyangga',
                'aktif' => true,
                'created_at' => now(),
                'updated_at' => now()
            ],
            [
                'kode' => 'A2',
                'nama' => 'Subsidi Ongkos Angkut Logistik Laut',
                'deskripsi' => 'Meringankan biaya transportasi pengiriman garam ke industri di Jawa & Luar Jawa',
                'aktif' => true,
                'created_at' => now(),
                'updated_at' => now()
            ],
            [
                'kode' => 'A3',
                'nama' => 'Bantuan Teknologi Geomembran & Rumah Garam',
                'deskripsi' => 'Intensifikasi kualitas produksi untuk menghadapi anomali cuaca',
                'aktif' => true,
                'created_at' => now(),
                'updated_at' => now()
            ],
            [
                'kode' => 'A4',
                'nama' => 'Penguatan Kemitraan Pabrik Pengolahan (Off-taker)',
                'deskripsi' => 'Kontrak kepastian pembelian harga dasar langsung dengan industri pengolahan garam',
                'aktif' => true,
                'created_at' => now(),
                'updated_at' => now()
            ],
        ]);
    }
}
