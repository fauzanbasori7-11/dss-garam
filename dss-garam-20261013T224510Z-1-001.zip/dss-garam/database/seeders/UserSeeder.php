<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder
{
    public function run(): void
    {
        // 1. Akun Administrator / Pengambil Kebijakan
        User::updateOrCreate(
            ['email' => 'admin@dss-garam.com'],
            [
                'name' => 'Administrator DSS',
                'role' => 'admin',
                'instansi' => 'Bappeda & Dinas Perindustrian Jatim',
                'password' => Hash::make('admin123'),
            ]
        );

        // 2. Akun Pakar / Ahli Rantai Pasok Garam
        User::updateOrCreate(
            ['email' => 'pakar@dss-garam.com'],
            [
                'name' => 'Dr. Ir. H. Ahmad Fauzan, M.T.',
                'role' => 'pakar',
                'instansi' => 'Dinas Kelautan dan Perikanan Jawa Timur',
                'password' => Hash::make('pakar123'),
            ]
        );
    }
}
