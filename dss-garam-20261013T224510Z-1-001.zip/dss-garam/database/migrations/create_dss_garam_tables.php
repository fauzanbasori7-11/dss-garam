<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // 1. Tabel Kriteria DSS
        Schema::create('kriterias', function (Blueprint $table) {
            $table->id();
            $table->string('kode', 10)->unique(); // C1, C2, C3, dst.
            $table->string('nama');               // misal: Ketersediaan Stok, Stabilitas Harga
            $table->enum('tipe', ['benefit', 'cost'])->default('benefit');
            $table->decimal('bobot_default', 5, 4)->default(0.2000); // skala 0 - 1
            $table->text('deskripsi')->nullable();
            $table->timestamps();
        });

        // 2. Tabel Alternatif Kebijakan
        Schema::create('alternatifs', function (Blueprint $table) {
            $table->id();
            $table->string('kode', 10)->unique(); // A1, A2, A3, dst.
            $table->string('nama');               // misal: Penyerapan Buffer Stock, Subsidi Distribusi
            $table->text('deskripsi')->nullable();
            $table->boolean('aktif')->default(true);
            $table->timestamps();
        });

        // 3. Tabel Penilaian / Bobot dari Pakar (Expert Judgment)
        Schema::create('penilaian_pakars', function (Blueprint $table) {
            $table->id();
            $table->string('nama_pakar');
            $table->string('instansi')->nullable();
            $table->json('bobot_kriteria'); // Menyimpan array JSON bobot [C1 => 0.25, C2 => 0.35, ...]
            $table->text('catatan')->nullable();
            $table->timestamps();
        });

        // 4. Tabel Riwayat Hasil Simulasi (System Dynamics + ELECTRE)
        Schema::create('riwayat_simulasis', function (Blueprint $table) {
            $table->id();
            $table->string('judul_skenario');
            $table->json('parameter_sd');       // Parameter cuaca, curah hujan, target produksi
            $table->json('hasil_proyeksi_sd');  // Output timeline SD (produksi, konsumsi, stok)
            $table->json('hasil_electre');      // Skor bersih, matriks concordance, ranking final
            $table->string('rekomendasi_utama'); // Alternatif dengan ranking 1
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('riwayat_simulasis');
        Schema::dropIfExists('penilaian_pakars');
        Schema::dropIfExists('alternatifs');
        Schema::dropIfExists('kriterias');
    }
};
