{{-- resources/views/expert-judgment.blade.php --}}
<!DOCTYPE html>
<html lang="id" class="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>Expert Judgment - DSS Garam Madura</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script>tailwind.config={darkMode:'class',theme:{extend:{fontFamily:{sans:['Outfit','sans-serif']},colors:{brand:{400:'#38bdf8',500:'#0ea5e9'},dark:{800:'#1e293b',900:'#0f172a'}}}}}</script>
    <style>
        body{font-family:'Outfit',sans-serif;background-color:#0f172a;color:#f8fafc;background-image:radial-gradient(circle at 15% 50%,rgba(14,165,233,.05),transparent 25%),radial-gradient(circle at 85% 30%,rgba(129,140,248,.05),transparent 25%)}
        .glass-card{background:rgba(30,41,59,.6);backdrop-filter:blur(16px);border:1px solid rgba(255,255,255,.05);border-radius:1.25rem;transition:all .3s}
        .glass-card:hover{transform:translateY(-2px);box-shadow:0 12px 30px -10px rgba(14,165,233,.15);border:1px solid rgba(56,189,248,.3)}
        .gradient-text{background:linear-gradient(135deg,#38bdf8,#818cf8);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
        .gradient-bg{background:linear-gradient(135deg,#0ea5e9,#6366f1)}
        ::-webkit-scrollbar{width:6px}::-webkit-scrollbar-track{background:transparent}::-webkit-scrollbar-thumb{background:#334155;border-radius:4px}
        input[type=range]{-webkit-appearance:none;width:100%;height:6px;border-radius:4px;background:#334155;outline:none;}
        input[type=range]::-webkit-slider-thumb{-webkit-appearance:none;width:18px;height:18px;border-radius:50%;background:#0ea5e9;cursor:pointer;box-shadow:0 0 8px rgba(14,165,233,0.5)}
        input[type=text],input[type=email],select,textarea{background:rgba(30,41,59,0.8);border:1px solid rgba(255,255,255,0.08);border-radius:0.75rem;color:#f8fafc;padding:0.75rem 1rem;width:100%;outline:none;transition:all .2s}
        input[type=text]:focus,input[type=email]:focus,select:focus,textarea:focus{border-color:#0ea5e9;box-shadow:0 0 0 3px rgba(14,165,233,0.2)}
    </style>
</head>
<body class="flex h-screen overflow-hidden antialiased">

    {{-- Sidebar --}}
    <aside class="w-64 glass-card m-4 mr-2 flex flex-col justify-between hidden md:flex rounded-2xl relative z-10 overflow-hidden">
        <div class="absolute inset-0 bg-gradient-to-b from-purple-500/10 to-transparent opacity-50"></div>
        <div class="relative z-10">
            <div class="p-6 flex items-center gap-3 border-b border-white/5">
                <div class="w-10 h-10 rounded-xl gradient-bg flex items-center justify-center">
                    <i class="fa-solid fa-cube text-white text-lg"></i>
                </div>
                <div><h1 class="font-bold text-xl">SALT<span class="gradient-text">DSS</span></h1><p class="text-xs text-slate-400">Madura Analytics</p></div>
            </div>
            <nav class="p-4 space-y-2 mt-4">
                <a href="{{ url('/') }}" class="flex items-center gap-3 px-4 py-3 rounded-xl text-slate-400 hover:text-white hover:bg-white/5 transition-all"><i class="fa-solid fa-chart-line w-5 text-center"></i> Dashboard</a>
                <a href="{{ url('/system-dynamics') }}" class="flex items-center gap-3 px-4 py-3 rounded-xl text-slate-400 hover:text-white hover:bg-white/5 transition-all"><i class="fa-solid fa-gears w-5 text-center"></i> System Dynamics</a>
                <a href="{{ url('/dynamic-electre') }}" class="flex items-center gap-3 px-4 py-3 rounded-xl text-slate-400 hover:text-white hover:bg-white/5 transition-all"><i class="fa-solid fa-scale-balanced w-5 text-center"></i> Dynamic ELECTRE</a>
                <a href="{{ url('/expert-judgment') }}" class="flex items-center gap-3 px-4 py-3 rounded-xl bg-purple-500/10 text-purple-400 border border-purple-500/20 font-medium transition-all"><i class="fa-solid fa-users-gear w-5 text-center"></i> Expert Judgment</a>
            </nav>
        </div>
        {{-- Area Profil & Tombol Login/Logout di Pojok Kiri Bawah --}}
        <div class="p-4 relative z-10 border-t border-white/5 space-y-3">
            @auth
                <div class="p-3 rounded-xl bg-slate-800/60 border border-white/5 flex items-center justify-between">
                    <div class="flex items-center gap-2.5 overflow-hidden">
                        <img src="https://ui-avatars.com/api/?name={{ urlencode(auth()->user()->name) }}&background=a855f7&color=fff" 
                             alt="Avatar" class="w-8 h-8 rounded-full border border-purple-400/30 flex-shrink-0">
                        <div class="truncate">
                            <p class="text-xs font-semibold text-white truncate">{{ auth()->user()->name }}</p>
                            <p class="text-[10px] text-purple-400 capitalize">{{ auth()->user()->role ?? 'Pakar' }}</p>
                        </div>
                    </div>
                    <form action="{{ route('logout') }}" method="POST" class="m-0">
                        @csrf
                        <button type="submit" title="Keluar / Logout" 
                                class="w-7 h-7 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 flex items-center justify-center transition-all">
                            <i class="fa-solid fa-power-off text-xs"></i>
                        </button>
                    </form>
                </div>
            @else
                <a href="{{ route('login') }}" 
                   class="w-full flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-gradient-to-r from-purple-500 to-indigo-600 hover:from-purple-600 hover:to-indigo-700 text-white text-xs font-semibold shadow-lg shadow-purple-500/20 transition-all">
                    <i class="fa-solid fa-arrow-right-to-bracket text-xs"></i>
                    <span>Masuk ke Akun</span>
                </a>
            @endauth
        </div>
    </aside>

    <main class="flex-1 flex flex-col h-full overflow-y-auto p-4 pl-2">
        <header class="flex justify-between items-center mb-8 px-2 mt-2">
            <div>
                <h2 class="text-2xl font-bold flex items-center gap-3"><i class="fa-solid fa-users-gear text-purple-400"></i> Form Penilaian Pakar</h2>
                <p class="text-sm text-slate-400 mt-1">Input bobot kriteria dari para ahli & tersimpan langsung ke Database MySQL</p>
            </div>
            <div class="glass-card px-4 py-2 text-sm flex items-center gap-2 text-purple-400">
                <i class="fa-solid fa-database"></i> Terhubung MySQL
            </div>
        </header>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {{-- Form Penilaian --}}
            <div class="lg:col-span-2">
                <div class="glass-card p-6">
                    <h3 class="text-lg font-semibold mb-6 flex items-center gap-2">
                        <i class="fa-solid fa-pen-to-square text-purple-400"></i> Form Input Bobot Kriteria
                    </h3>
                    <form id="form-pakar" class="space-y-6" onsubmit="event.preventDefault(); submitPenilaian();">
                        {{-- Info Pakar --}}
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label class="block text-sm text-slate-400 mb-2">Nama Lengkap Pakar</label>
                                <input type="text" id="nama_pakar" name="nama_pakar" placeholder="Contoh: Dr. Ir. H. Ahmad Fauzan, M.T." required>
                            </div>
                            <div>
                                <label class="block text-sm text-slate-400 mb-2">Instansi / Lembaga</label>
                                <input type="text" id="instansi" name="instansi" placeholder="Contoh: Dinas Kelautan & Perikanan Jatim">
                            </div>
                        </div>

                        <div class="h-px bg-white/5 my-2"></div>

                        {{-- Bobot Kriteria Dinamis dari Database --}}
                        <div>
                            <p class="text-sm font-semibold text-slate-300 mb-4">Pengaturan Bobot Kriteria <span class="text-xs text-slate-500">(Total bobot ideal = 1.0)</span></p>
                            <div class="space-y-6" id="bobot-container">
                                @forelse($kriterias as $c)
                                <div class="p-4 rounded-xl bg-white/[0.03] border border-white/5">
                                    <div class="flex justify-between items-center mb-3">
                                        <div>
                                            <p class="font-medium text-sm text-white">{{ $c->kode }} — {{ $c->nama }}</p>
                                            <span class="text-xs px-2 py-0.5 rounded-full {{ $c->tipe == 'benefit' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-rose-500/20 text-rose-400' }}">{{ strtoupper($c->tipe) }}</span>
                                        </div>
                                        <span id="val-{{ $c->kode }}" class="text-2xl font-bold text-white">{{ number_format($c->bobot_default, 2) }}</span>
                                    </div>
                                    <input type="range" name="bobot[{{ $c->kode }}]" id="slider-{{ $c->kode }}"
                                        min="0" max="1" step="0.01" value="{{ $c->bobot_default }}"
                                        oninput="updateVal('{{ $c->kode }}', this.value)">
                                    <p class="text-xs text-slate-400 mt-2"><i class="fa-solid fa-circle-info mr-1"></i> {{ $c->deskripsi }}</p>
                                </div>
                                @empty
                                <div class="p-4 text-center text-slate-400">Belum ada data kriteria di database.</div>
                                @endforelse
                            </div>
                        </div>

                        {{-- Catatan Pakar --}}
                        <div>
                            <label class="block text-sm text-slate-400 mb-2">Catatan Kualitatif / Alasan Pembobotan</label>
                            <textarea id="catatan" rows="3" placeholder="Tuliskan catatan tambahan mengenai kondisi rantai pasok garam..."></textarea>
                        </div>

                        {{-- Status Total Bobot --}}
                        <div id="total-card" class="flex items-center justify-between p-4 rounded-xl border border-emerald-500/30 bg-emerald-500/5">
                            <div>
                                <p class="text-sm font-medium text-white">Akumulasi Total Bobot</p>
                                <p class="text-xs text-slate-400">Batas toleransi sistem: 0.98 - 1.02</p>
                            </div>
                            <span id="total-bobot" class="text-2xl font-bold text-emerald-400">1.00</span>
                        </div>

                        {{-- Tombol Simpan --}}
                        <button type="submit" id="btn-submit"
                            class="w-full py-3.5 px-6 rounded-xl bg-gradient-to-r from-purple-500 to-indigo-600 hover:from-purple-600 hover:to-indigo-700 font-semibold text-white transition-all shadow-lg shadow-purple-500/20 flex items-center justify-center gap-2">
                            <i id="submit-icon" class="fa-solid fa-floppy-disk"></i>
                            <span id="submit-text">Simpan Penilaian ke Database</span>
                        </button>
                    </form>
                </div>
            </div>

            {{-- Riwayat Penilaian Pakar (Database) --}}
            <div class="space-y-6">
                <div class="glass-card p-6">
                    <h3 class="text-lg font-semibold mb-4 flex items-center gap-2">
                        <i class="fa-solid fa-clock-rotate-left text-purple-400"></i> Riwayat Input Pakar
                    </h3>
                    <div class="space-y-3 max-h-[500px] overflow-y-auto pr-1" id="daftar-pakar">
                        @forelse($daftarPakar as $p)
                        <div class="p-3.5 rounded-xl bg-white/[0.02] border border-white/5 hover:border-purple-500/30 transition-all">
                            <div class="flex justify-between items-start">
                                <div>
                                    <p class="font-semibold text-sm text-white">{{ $p->nama_pakar }}</p>
                                    <p class="text-xs text-slate-400">{{ $p->instansi }}</p>
                                </div>
                                <span class="text-[10px] text-slate-500">{{ $p->created_at->diffForHumans() }}</span>
                            </div>
                            <div class="mt-2.5 flex flex-wrap gap-1.5">
                                @if(is_array($p->bobot_kriteria))
                                    @foreach($p->bobot_kriteria as $k => $v)
                                    <span class="text-[11px] px-2 py-0.5 rounded bg-purple-500/10 text-purple-300 font-mono">
                                        {{ $k }}: {{ number_format($v, 2) }}
                                    </span>
                                    @endforeach
                                @endif
                            </div>
                        </div>
                        @empty
                        <p class="text-sm text-slate-500 text-center py-6">Belum ada riwayat penilaian pakar tersimpan.</p>
                        @endforelse
                    </div>
                </div>
            </div>
        </div>
    </main>

    {{-- Toast Notifikasi --}}
    <div id="toast" class="fixed bottom-6 right-6 hidden glass-card p-4 flex items-center gap-3 z-50 shadow-2xl border border-white/10">
        <div id="toast-icon" class="w-10 h-10 rounded-full flex items-center justify-center"></div>
        <div>
            <h4 id="toast-title" class="font-bold text-sm text-white"></h4>
            <p id="toast-msg" class="text-xs text-slate-400"></p>
        </div>
    </div>

    <script>
    function updateVal(kode, val) {
        document.getElementById('val-' + kode).textContent = parseFloat(val).toFixed(2);
        updateSliderBg(kode, val);
        updateTotal();
    }

    function updateSliderBg(kode, val) {
        const slider = document.getElementById('slider-' + kode);
        if(!slider) return;
        const pct = (val - slider.min) / (slider.max - slider.min) * 100;
        slider.style.background = `linear-gradient(to right, #a855f7 0%, #a855f7 ${pct}%, #334155 ${pct}%, #334155 100%)`;
    }

    function updateTotal() {
        const sliders = document.querySelectorAll('input[type=range]');
        let total = 0;
        sliders.forEach(s => total += parseFloat(s.value));
        total = parseFloat(total.toFixed(2));
        const el = document.getElementById('total-bobot');
        const card = document.getElementById('total-card');
        el.textContent = total.toFixed(2);

        if (Math.abs(total - 1.0) <= 0.03) {
            el.className = 'text-2xl font-bold text-emerald-400';
            card.className = 'flex items-center justify-between p-4 rounded-xl border border-emerald-500/30 bg-emerald-500/5';
        } else {
            el.className = 'text-2xl font-bold text-rose-400';
            card.className = 'flex items-center justify-between p-4 rounded-xl border border-rose-500/30 bg-rose-500/5';
        }
    }

    // Inisialisasi awal slider
    document.querySelectorAll('input[type=range]').forEach(s => {
        const kode = s.id.replace('slider-', '');
        updateSliderBg(kode, s.value);
    });
    updateTotal();

    async function submitPenilaian() {
        const nama = document.getElementById('nama_pakar').value;
        const instansi = document.getElementById('instansi').value;
        const catatan = document.getElementById('catatan').value;
        if (!nama) { alert('Nama pakar wajib diisi!'); return; }

        const sliders = document.querySelectorAll('input[type=range]');
        let bobot = {};
        let total = 0;
        sliders.forEach(s => {
            const key = s.name.replace('bobot[','').replace(']','');
            bobot[key] = parseFloat(s.value);
            total += parseFloat(s.value);
        });

        if (Math.abs(total - 1.0) > 0.03) {
            showToast('error', 'Total Bobot Tidak Tepat', `Total bobot saat ini ${total.toFixed(2)}, harus seimbang ~ 1.00`);
            return;
        }

        const btn = document.getElementById('btn-submit');
        const icon = document.getElementById('submit-icon');
        const text = document.getElementById('submit-text');
        
        btn.disabled = true;
        icon.className = 'fa-solid fa-spinner fa-spin';
        text.textContent = 'Menyimpan ke Database...';

        try {
            const res = await fetch('/pakar/simpan', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
                    'Accept': 'application/json'
                },
                body: JSON.stringify({ 
                    nama_pakar: nama, 
                    instansi: instansi,
                    bobot: bobot,
                    catatan: catatan
                })
            });
            const data = await res.json();
            if (data.status === 'success') {
                showToast('success', 'Berhasil Disimpan!', data.message);
                setTimeout(() => location.reload(), 1500);
            } else {
                showToast('error', 'Gagal Menyimpan', data.message);
            }
        } catch(e) {
            showToast('error', 'Koneksi Error', e.message);
        } finally {
            btn.disabled = false;
            icon.className = 'fa-solid fa-floppy-disk';
            text.textContent = 'Simpan Penilaian ke Database';
        }
    }

    function showToast(type, title, msg) {
        const toast = document.getElementById('toast');
        const icon = document.getElementById('toast-icon');
        icon.innerHTML = type === 'success'
            ? '<i class="fa-solid fa-check-circle text-xl text-emerald-400"></i>'
            : '<i class="fa-solid fa-circle-xmark text-xl text-rose-400"></i>';
        icon.className = `w-10 h-10 rounded-full flex items-center justify-center ${type === 'success' ? 'bg-emerald-500/20' : 'bg-rose-500/20'}`;
        document.getElementById('toast-title').textContent = title;
        document.getElementById('toast-msg').textContent = msg;
        toast.classList.remove('hidden');
        setTimeout(() => toast.classList.add('hidden'), 5000);
    }
    </script>
</body>
</html>
