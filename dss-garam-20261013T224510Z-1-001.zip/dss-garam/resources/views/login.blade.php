{{-- resources/views/auth/login.blade.php --}}
<!DOCTYPE html>
<html lang="id" class="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - DSS Garam Madura</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script>tailwind.config={darkMode:'class',theme:{extend:{fontFamily:{sans:['Outfit','sans-serif']},colors:{brand:{400:'#38bdf8',500:'#0ea5e9'},dark:{800:'#1e293b',900:'#0f172a'}}}}}</script>
    <style>
        body{font-family:'Outfit',sans-serif;background-color:#0f172a;color:#f8fafc;background-image:radial-gradient(circle at 15% 50%,rgba(14,165,233,.08),transparent 35%),radial-gradient(circle at 85% 30%,rgba(129,140,248,.08),transparent 35%)}
        .glass-card{background:rgba(30,41,59,.65);backdrop-filter:blur(20px);border:1px solid rgba(255,255,255,.08);border-radius:1.5rem;box-shadow:0 20px 40px -15px rgba(0,0,0,0.5)}
        .gradient-text{background:linear-gradient(135deg,#38bdf8,#818cf8);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
        .gradient-bg{background:linear-gradient(135deg,#0ea5e9,#6366f1)}
        input{background:rgba(15,23,42,0.8);border:1px solid rgba(255,255,255,0.08);border-radius:0.75rem;color:#f8fafc;padding:0.85rem 1rem;width:100%;outline:none;transition:all .2s}
        input:focus{border-color:#0ea5e9;box-shadow:0 0 0 3px rgba(14,165,233,0.2)}
    </style>
</head>
<body class="flex items-center justify-center min-h-screen p-4 antialiased">

    <div class="w-full max-w-md">
        {{-- Logo Header --}}
        <div class="text-center mb-8">
            <div class="w-14 h-14 rounded-2xl gradient-bg flex items-center justify-center mx-auto mb-3 shadow-xl shadow-sky-500/20">
                <i class="fa-solid fa-cube text-white text-2xl"></i>
            </div>
            <h1 class="text-2xl font-bold tracking-wide">SALT<span class="gradient-text">DSS</span></h1>
            <p class="text-xs text-slate-400 mt-1">Sistem Pendukung Keputusan Rantai Pasok Garam Madura</p>
        </div>

        {{-- Form Login Card --}}
        <div class="glass-card p-8">
            <h2 class="text-xl font-bold mb-1">Selamat Datang</h2>
            <p class="text-xs text-slate-400 mb-6">Silakan masuk menggunakan akun Administrator atau Pakar.</p>

            @if($errors->any())
            <div class="p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-400 text-xs mb-5 flex items-center gap-2">
                <i class="fa-solid fa-circle-exclamation text-sm"></i>
                <span>{{ $errors->first() }}</span>
            </div>
            @endif

            <form action="{{ url('/login') }}" method="POST" class="space-y-4">
                @csrf
                <div>
                    <label class="block text-xs text-slate-400 mb-2">Alamat Email</label>
                    <div class="relative">
                        <input type="email" name="email" value="{{ old('email') }}" placeholder="admin@dss-garam.com" required autofocus>
                    </div>
                </div>

                <div>
                    <div class="flex justify-between items-center mb-2">
                        <label class="block text-xs text-slate-400">Kata Sandi</label>
                    </div>
                    <div class="relative">
                        <input type="password" name="password" placeholder="••••••••" required>
                    </div>
                </div>

                <div class="flex items-center justify-between text-xs pt-1">
                    <label class="flex items-center gap-2 text-slate-400 cursor-pointer">
                        <input type="checkbox" name="remember" class="w-4 h-4 rounded bg-slate-800 border-white/10 accent-sky-500">
                        <span>Ingat saya di perangkat ini</span>
                    </label>
                </div>

                <button type="submit" class="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-sky-500 to-indigo-600 hover:from-sky-600 hover:to-indigo-700 font-semibold text-white text-sm transition-all shadow-lg shadow-sky-500/25 mt-2 flex items-center justify-center gap-2">
                    <i class="fa-solid fa-arrow-right-to-bracket"></i> Masuk ke Sistem
                </button>
            </form>

            {{-- Demo Account Hint --}}
            <div class="mt-8 pt-6 border-t border-white/5">
                <p class="text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-2 text-center">Akun Demo yang Tersedia:</p>
                <div class="grid grid-cols-2 gap-2 text-xs">
                    <div class="p-2.5 rounded-lg bg-white/[0.02] border border-white/5">
                        <p class="font-bold text-sky-400 flex items-center gap-1.5"><i class="fa-solid fa-shield-halved"></i> Admin</p>
                        <p class="text-[11px] text-slate-400 mt-0.5">admin@dss-garam.com</p>
                        <p class="text-[11px] text-slate-500 font-mono">admin123</p>
                    </div>
                    <div class="p-2.5 rounded-lg bg-white/[0.02] border border-white/5">
                        <p class="font-bold text-purple-400 flex items-center gap-1.5"><i class="fa-solid fa-user-tie"></i> Pakar</p>
                        <p class="text-[11px] text-slate-400 mt-0.5">pakar@dss-garam.com</p>
                        <p class="text-[11px] text-slate-500 font-mono">pakar123</p>
                    </div>
                </div>
            </div>
        </div>

        <p class="text-center text-[11px] text-slate-500 mt-6">
            &copy; {{ date('Y') }} SALT-DSS Madura Analytics. Hak Cipta Dilindungi.
        </p>
    </div>

</body>
</html>
