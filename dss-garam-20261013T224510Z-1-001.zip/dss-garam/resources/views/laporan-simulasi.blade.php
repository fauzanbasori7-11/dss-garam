<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Laporan Hasil Simulasi DSS Garam Madura</title>
    <style>
        body {
            font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;
            color: #333;
            font-size: 12px;
            line-height: 1.5;
            padding: 20px;
        }
        .header {
            text-align: center;
            border-bottom: 2px solid #0284c7;
            padding-bottom: 12px;
            margin-bottom: 20px;
        }
        .header h1 {
            margin: 0;
            font-size: 18px;
            color: #0f172a;
            text-transform: uppercase;
        }
        .header p {
            margin: 4px 0 0 0;
            color: #64748b;
            font-size: 11px;
        }
        .badge {
            background-color: #0ea5e9;
            color: #fff;
            padding: 4px 10px;
            border-radius: 4px;
            font-weight: bold;
            display: inline-block;
        }
        .section-title {
            font-size: 13px;
            font-weight: bold;
            color: #0369a1;
            margin-top: 18px;
            margin-bottom: 8px;
            border-left: 3px solid #0284c7;
            padding-left: 8px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 8px;
            margin-bottom: 15px;
        }
        th, td {
            border: 1px solid #cbd5e1;
            padding: 7px 10px;
            text-align: left;
        }
        th {
            background-color: #f1f5f9;
            color: #334155;
            font-weight: 600;
        }
        .highlight-box {
            background-color: #f0f9ff;
            border: 1px solid #bae6fd;
            border-radius: 6px;
            padding: 12px;
            margin-bottom: 15px;
        }
        .footer {
            margin-top: 35px;
            text-align: right;
            font-size: 10px;
            color: #94a3b8;
        }
        @media print {
            .no-print { display: none; }
            body { padding: 0; }
        }
    </style>
</head>
<body>

    <div class="no-print" style="margin-bottom: 20px; text-align: right;">
        <button onclick="window.print()" style="background: #0284c7; color: white; border: none; padding: 8px 16px; border-radius: 6px; cursor: pointer; font-weight: bold;">
            🖨 Cetak / Simpan PDF
        </button>
    </div>

    <div class="header">
        <h1>Laporan Rekomendasi Kebijakan Garam Madura</h1>
        <p>Sistem Pendukung Keputusan Berbasis Integrasi System Dynamics & Dynamic ELECTRE II</p>
        <p>Waktu Simulasi: {{ $simulasi->created_at->format('d F Y, H:i:s') }} WIB</p>
    </div>

    {{-- Ringkasan Eksekutif --}}
    <div class="highlight-box">
        <strong style="color: #0369a1; font-size: 13px;">Rekomendasi Kebijakan Utama:</strong>
        <h2 style="margin: 6px 0; color: #0284c7; font-size: 16px;">
            {{ $simulasi->rekomendasi_utama }}
        </h2>
        <p style="margin: 0; color: #475569;">
            Alternatif ini memperoleh skor dominasi outranking tertinggi secara dinamis di seluruh periode pengujian (Q1 - Q3).
        </p>
    </div>

    {{-- Parameter Simulasi SD --}}
    <div class="section-title">1. Parameter Input System Dynamics</div>
    <table>
        <tr>
            <th width="35%">Skenario Simulasi</th>
            <td>{{ $simulasi->judul_skenario }}</td>
        </tr>
        <tr>
            <th>Curah Hujan Proyeksi</th>
            <td>{{ $simulasi->parameter_sd['curah_hujan'] ?? '-' }} mm/bulan</td>
        </tr>
        <tr>
            <th>Kapasitas Gudang Penyangga</th>
            <td>{{ number_format($simulasi->parameter_sd['kapasitas_gudang'] ?? 0) }} Ton</td>
        </tr>
    </table>

    {{-- Bobot Kriteria Pakar --}}
    <div class="section-title">2. Bobot Kriteria yang Digunakan</div>
    <table>
        <thead>
            <tr>
                <th>Kode Kriteria</th>
                <th>Nilai Bobot Terhitung</th>
                <th>Kategori</th>
            </tr>
        </thead>
        <tbody>
            @if(isset($simulasi->hasil_electre['weights_used']))
                @foreach($simulasi->hasil_electre['weights_used'] as $cKode => $bobot)
                <tr>
                    <td><strong>{{ $cKode }}</strong></td>
                    <td>{{ number_format($bobot, 4) }} ({{ round($bobot * 100, 1) }}%)</td>
                    <td>Normalisasi Pakar</td>
                </tr>
                @endforeach
            @endif
        </tbody>
    </table>

    {{-- Ranking Alternatif --}}
    <div class="section-title">3. Hasil Perankingan Dynamic ELECTRE (Akumulasi Net Score)</div>
    <table>
        <thead>
            <tr>
                <th width="12%">Peringkat</th>
                <th width="18%">Kode Alternatif</th>
                <th>Nama Kebijakan</th>
                <th width="20%">Skor Bersih (Net Score)</th>
            </tr>
        </thead>
        <tbody>
            @php $rank = 1; @endphp
            @if(isset($simulasi->hasil_electre['accumulated_scores']))
                @foreach($simulasi->hasil_electre['accumulated_scores'] as $altKode => $score)
                <tr style="{{ $rank == 1 ? 'background-color: #f0fdf4; font-weight: bold;' : '' }}">
                    <td align="center">#{{ $rank++ }}</td>
                    <td>{{ $altKode }}</td>
                    <td>{{ $namaAlternatif[$altKode] ?? $altKode }}</td>
                    <td>{{ $score > 0 ? '+'.$score : $score }}</td>
                </tr>
                @endforeach
            @endif
        </tbody>
    </table>

    <div class="footer">
        Dicetak secara otomatis oleh SALT-DSS Madura Analytics Platform &bull; Halaman 1 dari 1
    </div>

</body>
</html>
