<!DOCTYPE html>
<html lang="id" class="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DSS Garam Madura - Integrasi SD & ELECTRE</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['Outfit', 'sans-serif'],
                    },
                    colors: {
                        brand: {
                            400: '#38bdf8',
                            500: '#0ea5e9',
                            600: '#0284c7',
                        },
                        dark: {
                            800: '#1e293b',
                            900: '#0f172a',
                        }
                    }
                }
            }
        }
    </script>
    <style>
        body { 
            font-family: 'Outfit', sans-serif; 
            background-color: #0f172a; 
            color: #f8fafc; 
            background-image: 
                radial-gradient(circle at 15% 50%, rgba(14, 165, 233, 0.05), transparent 25%),
                radial-gradient(circle at 85% 30%, rgba(129, 140, 248, 0.05), transparent 25%);
        }
        .glass-card {
            background: rgba(30, 41, 59, 0.6);
            backdrop-filter: blur(16px);
            -webkit-backdrop-filter: blur(16px);
            border: 1px solid rgba(255, 255, 255, 0.05);
            border-radius: 1.25rem;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .glass-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 12px 30px -10px rgba(14, 165, 233, 0.15);
            border: 1px solid rgba(56, 189, 248, 0.3);
        }
        .gradient-text {
            background: linear-gradient(135deg, #38bdf8 0%, #818cf8 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        .gradient-bg {
            background: linear-gradient(135deg, #0ea5e9 0%, #6366f1 100%);
        }
        
        /* Custom Scrollbar */
        ::-webkit-scrollbar { width: 6px; height: 6px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: #334155; border-radius: 4px; }
        ::-webkit-scrollbar-thumb:hover { background: #475569; }

        /* Animation for table rows */
        tbody tr {
            transition: background-color 0.2s ease;
        }
        tbody tr:hover {
            background-color: rgba(56, 189, 248, 0.05);
        }
    </style>
</head>
<body class="flex h-screen overflow-hidden antialiased">

    <!-- Sidebar -->
    <aside class="w-64 glass-card m-4 mr-2 flex flex-col justify-between hidden md:flex border-r-0 rounded-2xl relative z-10 overflow-hidden">
        <div class="absolute inset-0 bg-gradient-to-b from-brand-500/10 to-transparent opacity-50"></div>
        <div class="relative z-10">
            <div class="p-6 flex items-center gap-3 border-b border-white/5">
                <div class="w-10 h-10 rounded-xl gradient-bg flex items-center justify-center shadow-lg shadow-brand-500/30">
                    <i class="fa-solid fa-cube text-white text-lg"></i>
                </div>
                <div>
                    <h1 class="font-bold text-xl tracking-wide">SALT<span class="gradient-text">DSS</span></h1>
                    <p class="text-xs text-slate-400">Madura Analytics</p>
                </div>
            </div>
            <nav class="p-4 space-y-2 mt-4">
                <a href="#" class="flex items-center gap-3 px-4 py-3 rounded-xl bg-brand-500/10 text-brand-400 border border-brand-500/20 font-medium transition-all">
                    <i class="fa-solid fa-chart-line w-5 text-center"></i>
                    Dashboard
                </a>
                <a href="#" class="flex items-center gap-3 px-4 py-3 rounded-xl text-slate-400 hover:text-white hover:bg-white/5 transition-all">
                    <i class="fa-solid fa-gears w-5 text-center"></i>
                    System Dynamics
                </a>
                <a href="#" class="flex items-center gap-3 px-4 py-3 rounded-xl text-slate-400 hover:text-white hover:bg-white/5 transition-all">
                    <i class="fa-solid fa-scale-balanced w-5 text-center"></i>
                    Dynamic ELECTRE
                </a>
                <a href="#" class="flex items-center gap-3 px-4 py-3 rounded-xl text-slate-400 hover:text-white hover:bg-white/5 transition-all">
                    <i class="fa-solid fa-users-gear w-5 text-center"></i>
                    Expert Judgment
                </a>
            </nav>
        </div>
        <div class="p-4 relative z-10">
            <div class="p-4 rounded-xl bg-dark-800/50 border border-white/5 flex items-center gap-3">
                <img src="https://ui-avatars.com/api/?name=Akhmad+Fauzan&background=0D8ABC&color=fff" alt="User" class="w-10 h-10 rounded-full border border-brand-500/50">
                <div>
                    <p class="text-sm font-medium text-white">Akhmad Fauzan</p>
                    <p class="text-xs text-brand-400">System Admin</p>
                </div>
            </div>
        </div>
    </aside>

    <!-- Main Content -->
    <main class="flex-1 flex flex-col h-full relative overflow-y-auto overflow-x-hidden p-4 pl-2">
        
        <!-- Header -->
        <header class="flex justify-between items-center mb-8 px-2 mt-2">
            <div>
                <h2 class="text-2xl font-bold">Ringkasan Analisis Kebijakan</h2>
                <p class="text-sm text-slate-400 mt-1">Evaluasi Integratif System Dynamics & ELECTRE (Periode 2026 - 2030)</p>
            </div>
            <div class="flex gap-4">
                <button class="px-4 py-2 glass-card rounded-lg text-sm flex items-center gap-2 hover:text-brand-400 transition-colors">
                    <i class="fa-solid fa-calendar-days"></i> 2026 - 2030
                </button>
                <button class="px-5 py-2 gradient-bg rounded-lg text-sm font-medium shadow-lg shadow-brand-500/20 hover:shadow-brand-500/40 transition-shadow">
                    <i class="fa-solid fa-play mr-2"></i> Jalankan Simulasi
                </button>
            </div>
        </header>

        <!-- KPI Cards -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <div class="glass-card p-6 relative overflow-hidden group">
                <div class="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity"><i class="fa-solid fa-industry text-5xl"></i></div>
                <p class="text-slate-400 text-sm font-medium mb-1">Proyeksi Produksi (2030)</p>
                <h3 class="text-3xl font-bold text-white">1.2M <span class="text-lg font-normal text-slate-400">Ton</span></h3>
                <div class="mt-4 flex items-center gap-2 text-emerald-400 text-sm font-medium">
                    <i class="fa-solid fa-arrow-trend-up"></i> +14.5% vs Baseline
                </div>
            </div>
            
            <div class="glass-card p-6 relative overflow-hidden group">
                <div class="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity"><i class="fa-solid fa-warehouse text-5xl"></i></div>
                <p class="text-slate-400 text-sm font-medium mb-1">Kapasitas Gudang</p>
                <h3 class="text-3xl font-bold text-white">85<span class="text-lg font-normal text-slate-400">%</span></h3>
                <div class="mt-4 flex items-center gap-2 text-rose-400 text-sm font-medium">
                    <i class="fa-solid fa-triangle-exclamation"></i> Mendekati batas maksimal
                </div>
            </div>

            <div class="glass-card p-6 relative overflow-hidden group">
                <div class="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity"><i class="fa-solid fa-money-bill-trend-up text-5xl"></i></div>
                <p class="text-slate-400 text-sm font-medium mb-1">Serapan Industri</p>
                <h3 class="text-3xl font-bold text-white">68<span class="text-lg font-normal text-slate-400">%</span></h3>
                <div class="mt-4 flex items-center gap-2 text-emerald-400 text-sm font-medium">
                    <i class="fa-solid fa-arrow-trend-up"></i> +5.2% via Hilirisasi
                </div>
            </div>

            <div class="glass-card p-6 relative overflow-hidden group gradient-bg border-none">
                <div class="absolute inset-0 bg-black/10"></div>
                <div class="relative z-10">
                    <p class="text-white/80 text-sm font-medium mb-1">Rekomendasi Utama (2026)</p>
                    <h3 class="text-2xl font-bold text-white mt-2">Geomembran (A2)</h3>
                    <div class="mt-4 flex items-center gap-2 text-white/90 text-sm font-medium bg-white/10 w-fit px-3 py-1 rounded-full backdrop-blur-md">
                        <i class="fa-solid fa-crown text-amber-300"></i> Rank #1
                    </div>
                </div>
            </div>
        </div>

        <!-- Charts Section -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
            <!-- System Dynamics Chart -->
            <div class="glass-card p-6 flex flex-col">
                <div class="flex justify-between items-center mb-6">
                    <div>
                        <h3 class="text-lg font-semibold flex items-center gap-2">
                            <i class="fa-solid fa-chart-area text-brand-400"></i> Simulasi System Dynamics
                        </h3>
                        <p class="text-xs text-slate-400">Proyeksi Kesenjangan Pasokan vs Produksi</p>
                    </div>
                </div>
                <div class="flex-1 min-h-[300px] w-full relative">
                    <canvas id="sdChart"></canvas>
                </div>
            </div>

            <!-- ELECTRE Output -->
            <div class="glass-card p-6 flex flex-col">
                <div class="flex justify-between items-center mb-6">
                    <div>
                        <h3 class="text-lg font-semibold flex items-center gap-2">
                            <i class="fa-solid fa-network-wired text-indigo-400"></i> Dynamic ELECTRE Outranking
                        </h3>
                        <p class="text-xs text-slate-400">Net Concordance Score berdasarkan Periode</p>
                    </div>
                </div>
                <div class="flex-1 min-h-[300px] w-full relative">
                    <canvas id="electreChart"></canvas>
                </div>
            </div>
        </div>

        <!-- Dynamic Ranking Table -->
        <div class="glass-card p-0 overflow-hidden mb-8 flex flex-col">
            <div class="p-6 border-b border-white/5 flex justify-between items-center bg-white/[0.02]">
                <h3 class="text-lg font-semibold">Pergeseran Prioritas Kebijakan (Matrix Keputusan)</h3>
                <span class="text-xs font-medium bg-brand-500/20 text-brand-400 px-3 py-1 rounded-full border border-brand-500/20">Auto-updated from Vensim Model</span>
            </div>
            <div class="overflow-x-auto">
                <table class="w-full text-left border-collapse">
                    <thead>
                        <tr class="border-b border-white/10 text-sm text-slate-400 bg-white/[0.01]">
                            <th class="p-4 font-medium pl-6">Alternatif Kebijakan</th>
                            <th class="p-4 font-medium text-center">Rank (t=2026)</th>
                            <th class="p-4 font-medium text-center">Rank (t=2028)</th>
                            <th class="p-4 font-medium text-center">Rank (t=2030)</th>
                            <th class="p-4 font-medium">Status / Perubahan</th>
                        </tr>
                    </thead>
                    <tbody class="text-sm font-medium">
                        <tr class="border-b border-white/5">
                            <td class="p-4 pl-6 flex items-center gap-3">
                                <div class="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center"><i class="fa-solid fa-layer-group"></i></div>
                                <span>A2 - Implementasi Geomembran</span>
                            </td>
                            <td class="p-4 text-center"><span class="bg-amber-500 text-white w-6 h-6 rounded-full inline-flex items-center justify-center text-xs shadow-lg shadow-amber-500/30">1</span></td>
                            <td class="p-4 text-center"><span class="bg-slate-700 text-white w-6 h-6 rounded-full inline-flex items-center justify-center text-xs">2</span></td>
                            <td class="p-4 text-center"><span class="bg-slate-700 text-white w-6 h-6 rounded-full inline-flex items-center justify-center text-xs">3</span></td>
                            <td class="p-4 text-rose-400"><i class="fa-solid fa-arrow-down mr-1"></i> Efektivitas Menurun</td>
                        </tr>
                        <tr class="border-b border-white/5">
                            <td class="p-4 pl-6 flex items-center gap-3">
                                <div class="w-8 h-8 rounded-lg bg-indigo-500/20 text-indigo-400 flex items-center justify-center"><i class="fa-solid fa-tents"></i></div>
                                <span>A1 - Tunnel Salt House</span>
                            </td>
                            <td class="p-4 text-center"><span class="bg-slate-700 text-white w-6 h-6 rounded-full inline-flex items-center justify-center text-xs">2</span></td>
                            <td class="p-4 text-center"><span class="bg-amber-500 text-white w-6 h-6 rounded-full inline-flex items-center justify-center text-xs shadow-lg shadow-amber-500/30">1</span></td>
                            <td class="p-4 text-center"><span class="bg-slate-700 text-white w-6 h-6 rounded-full inline-flex items-center justify-center text-xs">2</span></td>
                            <td class="p-4 text-emerald-400"><i class="fa-solid fa-arrow-up mr-1"></i> Solusi Jangka Menengah</td>
                        </tr>
                        <tr class="border-b border-white/5">
                            <td class="p-4 pl-6 flex items-center gap-3">
                                <div class="w-8 h-8 rounded-lg bg-brand-500/20 text-brand-400 flex items-center justify-center"><i class="fa-solid fa-flask"></i></div>
                                <span>A5 - Hilirisasi Garam Industri</span>
                            </td>
                            <td class="p-4 text-center"><span class="bg-slate-700 text-white w-6 h-6 rounded-full inline-flex items-center justify-center text-xs">4</span></td>
                            <td class="p-4 text-center"><span class="bg-slate-700 text-white w-6 h-6 rounded-full inline-flex items-center justify-center text-xs">3</span></td>
                            <td class="p-4 text-center"><span class="bg-amber-500 text-white w-6 h-6 rounded-full inline-flex items-center justify-center text-xs shadow-lg shadow-amber-500/30">1</span></td>
                            <td class="p-4 text-emerald-400"><i class="fa-solid fa-arrow-up mr-1"></i> Prioritas Jangka Panjang</td>
                        </tr>
                        <tr class="border-b border-white/5">
                            <td class="p-4 pl-6 flex items-center gap-3">
                                <div class="w-8 h-8 rounded-lg bg-purple-500/20 text-purple-400 flex items-center justify-center"><i class="fa-solid fa-boxes-packing"></i></div>
                                <span>A3 - Penguatan Gudang</span>
                            </td>
                            <td class="p-4 text-center"><span class="bg-slate-700 text-white w-6 h-6 rounded-full inline-flex items-center justify-center text-xs">3</span></td>
                            <td class="p-4 text-center"><span class="bg-slate-700 text-white w-6 h-6 rounded-full inline-flex items-center justify-center text-xs">4</span></td>
                            <td class="p-4 text-center"><span class="bg-slate-700 text-white w-6 h-6 rounded-full inline-flex items-center justify-center text-xs">4</span></td>
                            <td class="p-4 text-slate-400"><i class="fa-solid fa-minus mr-1"></i> Stabil / Pendukung</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

    </main>

    <script>
        // Set defaults for charts
        Chart.defaults.color = '#94a3b8';
        Chart.defaults.font.family = "'Outfit', sans-serif";
        
        // System Dynamics Line Chart
        const sdCtx = document.getElementById('sdChart').getContext('2d');
        
        // Create gradient for SD chart
        const gradientProd = sdCtx.createLinearGradient(0, 0, 0, 400);
        gradientProd.addColorStop(0, 'rgba(14, 165, 233, 0.5)');
        gradientProd.addColorStop(1, 'rgba(14, 165, 233, 0.0)');
        
        const gradientBase = sdCtx.createLinearGradient(0, 0, 0, 400);
        gradientBase.addColorStop(0, 'rgba(244, 63, 94, 0.5)');
        gradientBase.addColorStop(1, 'rgba(244, 63, 94, 0.0)');

        new Chart(sdCtx, {
            type: 'line',
            data: {
                labels: ['2026', '2027', '2028', '2029', '2030'],
                datasets: [
                    {
                        label: 'Produksi (Skenario Intervensi A1+A2)',
                        data: [750, 820, 950, 1080, 1200],
                        borderColor: '#0ea5e9',
                        backgroundColor: gradientProd,
                        borderWidth: 3,
                        pointBackgroundColor: '#0ea5e9',
                        pointBorderColor: '#0f172a',
                        pointBorderWidth: 2,
                        pointRadius: 4,
                        fill: true,
                        tension: 0.4
                    },
                    {
                        label: 'Produksi (Baseline/Tanpa Kebijakan)',
                        data: [750, 740, 730, 710, 690],
                        borderColor: '#f43f5e',
                        backgroundColor: gradientBase,
                        borderWidth: 3,
                        borderDash: [5, 5],
                        pointBackgroundColor: '#f43f5e',
                        pointRadius: 0,
                        fill: true,
                        tension: 0.4
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { position: 'top', align: 'end', labels: { boxWidth: 12, usePointStyle: true } }
                },
                scales: {
                    y: { 
                        grid: { color: 'rgba(255, 255, 255, 0.05)', drawBorder: false },
                        title: { display: true, text: 'Ribu Ton' }
                    },
                    x: { grid: { display: false, drawBorder: false } }
                },
                interaction: { mode: 'index', intersect: false }
            }
        });

        // ELECTRE Bar Chart
        const elCtx = document.getElementById('electreChart').getContext('2d');
        new Chart(elCtx, {
            type: 'bar',
            data: {
                labels: ['A1 (Tunnel)', 'A2 (Geomembran)', 'A3 (Gudang)', 'A4 (Digitalisasi)', 'A5 (Hilirisasi)'],
                datasets: [
                    {
                        label: 'Skor Net Concordance (2026)',
                        data: [0.45, 0.72, 0.20, 0.15, -0.10],
                        backgroundColor: '#38bdf8',
                        borderRadius: 6,
                        barPercentage: 0.6
                    },
                    {
                        label: 'Skor Net Concordance (2030)',
                        data: [0.65, 0.30, 0.25, 0.40, 0.85],
                        backgroundColor: '#818cf8',
                        borderRadius: 6,
                        barPercentage: 0.6
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { position: 'top', align: 'end', labels: { boxWidth: 12, usePointStyle: true } }
                },
                scales: {
                    y: { 
                        grid: { color: 'rgba(255, 255, 255, 0.05)', drawBorder: false },
                    },
                    x: { grid: { display: false, drawBorder: false } }
                }
            }
        });
    </script>
</body>
</html>
<?php /**PATH D:\Laragon\www\dss-garam\resources\views/welcome.blade.php ENDPATH**/ ?>