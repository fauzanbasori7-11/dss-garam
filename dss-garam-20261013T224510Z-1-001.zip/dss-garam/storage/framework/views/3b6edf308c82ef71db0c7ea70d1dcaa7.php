
<!DOCTYPE html>
<html lang="id" class="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dynamic ELECTRE - DSS Garam Madura</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script>tailwind.config={darkMode:'class',theme:{extend:{fontFamily:{sans:['Outfit','sans-serif']},colors:{brand:{400:'#38bdf8',500:'#0ea5e9'},dark:{800:'#1e293b',900:'#0f172a'}}}}}</script>
    <style>
        body{font-family:'Outfit',sans-serif;background-color:#0f172a;color:#f8fafc;background-image:radial-gradient(circle at 15% 50%,rgba(14,165,233,.05),transparent 25%),radial-gradient(circle at 85% 30%,rgba(129,140,248,.05),transparent 25%)}
        .glass-card{background:rgba(30,41,59,.6);backdrop-filter:blur(16px);border:1px solid rgba(255,255,255,.05);border-radius:1.25rem;transition:all .3s}
        .glass-card:hover{transform:translateY(-2px);box-shadow:0 12px 30px -10px rgba(129,140,248,.2);border:1px solid rgba(129,140,248,.3)}
        .gradient-text{background:linear-gradient(135deg,#38bdf8,#818cf8);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
        .gradient-bg{background:linear-gradient(135deg,#0ea5e9,#6366f1)}
        ::-webkit-scrollbar{width:6px}::-webkit-scrollbar-track{background:transparent}::-webkit-scrollbar-thumb{background:#334155;border-radius:4px}
        .rank-badge-1{background:#f59e0b;box-shadow:0 0 12px rgba(245,158,11,.4)}
        .rank-badge-2{background:#64748b}
    </style>
</head>
<body class="flex h-screen overflow-hidden antialiased">

    
    <aside class="w-64 glass-card m-4 mr-2 flex flex-col justify-between hidden md:flex rounded-2xl relative z-10 overflow-hidden">
        <div class="absolute inset-0 bg-gradient-to-b from-indigo-500/10 to-transparent opacity-50"></div>
        <div class="relative z-10">
            <div class="p-6 flex items-center gap-3 border-b border-white/5">
                <div class="w-10 h-10 rounded-xl gradient-bg flex items-center justify-center">
                    <i class="fa-solid fa-cube text-white text-lg"></i>
                </div>
                <div><h1 class="font-bold text-xl">SALT<span class="gradient-text">DSS</span></h1><p class="text-xs text-slate-400">Madura Analytics</p></div>
            </div>
            <nav class="p-4 space-y-2 mt-4">
                <a href="<?php echo e(url('/')); ?>" class="flex items-center gap-3 px-4 py-3 rounded-xl text-slate-400 hover:text-white hover:bg-white/5 transition-all"><i class="fa-solid fa-chart-line w-5 text-center"></i> Dashboard</a>
                <a href="<?php echo e(url('/system-dynamics')); ?>" class="flex items-center gap-3 px-4 py-3 rounded-xl text-slate-400 hover:text-white hover:bg-white/5 transition-all"><i class="fa-solid fa-gears w-5 text-center"></i> System Dynamics</a>
                <a href="<?php echo e(url('/dynamic-electre')); ?>" class="flex items-center gap-3 px-4 py-3 rounded-xl bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 font-medium transition-all"><i class="fa-solid fa-scale-balanced w-5 text-center"></i> Dynamic ELECTRE</a>
                <a href="<?php echo e(url('/expert-judgment')); ?>" class="flex items-center gap-3 px-4 py-3 rounded-xl text-slate-400 hover:text-white hover:bg-white/5 transition-all"><i class="fa-solid fa-users-gear w-5 text-center"></i> Expert Judgment</a>
            </nav>
        </div>
        <div class="p-4 relative z-10 border-t border-white/5 space-y-3">
            <a href="<?php echo e(url('/laporan/cetak')); ?>" target="_blank" class="w-full flex items-center justify-center gap-2 p-2.5 rounded-xl bg-indigo-600/20 hover:bg-indigo-600/40 text-indigo-300 text-xs font-semibold border border-indigo-500/30 transition-all">
                <i class="fa-solid fa-print"></i> Cetak Laporan DSS
            </a>

            <?php if(auth()->guard()->check()): ?>
                <div class="p-3 rounded-xl bg-slate-800/60 border border-white/5 flex items-center justify-between">
                    <div class="flex items-center gap-2.5 overflow-hidden">
                        <img src="https://ui-avatars.com/api/?name=<?php echo e(urlencode(auth()->user()->name)); ?>&background=6366f1&color=fff" 
                             alt="Avatar" class="w-8 h-8 rounded-full border border-indigo-400/30 flex-shrink-0">
                        <div class="truncate">
                            <p class="text-xs font-semibold text-white truncate"><?php echo e(auth()->user()->name); ?></p>
                            <p class="text-[10px] text-indigo-400 capitalize"><?php echo e(auth()->user()->role ?? 'Admin'); ?></p>
                        </div>
                    </div>
                    <form action="<?php echo e(route('logout')); ?>" method="POST" class="m-0">
                        <?php echo csrf_field(); ?>
                        <button type="submit" title="Keluar / Logout" 
                                class="w-7 h-7 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 flex items-center justify-center transition-all">
                            <i class="fa-solid fa-power-off text-xs"></i>
                        </button>
                    </form>
                </div>
            <?php else: ?>
                <a href="<?php echo e(route('login')); ?>" 
                   class="w-full flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-gradient-to-r from-indigo-500 to-sky-600 hover:from-indigo-600 hover:to-sky-700 text-white text-xs font-semibold shadow-lg shadow-indigo-500/20 transition-all">
                    <i class="fa-solid fa-arrow-right-to-bracket text-xs"></i>
                    <span>Masuk ke Akun</span>
                </a>
            <?php endif; ?>
        </div>
    </aside>

    <main class="flex-1 flex flex-col h-full overflow-y-auto p-4 pl-2">
        <header class="flex justify-between items-center mb-8 px-2 mt-2">
            <div>
                <h2 class="text-2xl font-bold flex items-center gap-3"><i class="fa-solid fa-scale-balanced text-indigo-400"></i> Dynamic ELECTRE Outranking</h2>
                <p class="text-sm text-slate-400 mt-1">Evaluasi matriks dominasi outranking dan perankingan dinamis dari database</p>
            </div>
            <div class="flex items-center gap-3">
                <a href="<?php echo e(url('/laporan/cetak')); ?>" target="_blank" class="glass-card px-4 py-2 text-xs font-semibold flex items-center gap-2 text-indigo-300 hover:text-white transition-all">
                    <i class="fa-solid fa-file-pdf"></i> Ekspor PDF
                </a>
                <div class="glass-card px-4 py-2 text-xs flex items-center gap-2 text-indigo-400">
                    <i class="fa-solid fa-database"></i> Status: Sinkron MySQL
                </div>
            </div>
        </header>

        <?php
            $periodEvals = $latestSimulasi->hasil_electre['period_evaluations'] ?? [];
            $accScores   = $latestSimulasi->hasil_electre['accumulated_scores'] ?? [];
            $periods     = array_keys($periodEvals);
        ?>

        
        <div class="glass-card p-0 overflow-hidden mb-8">
            <div class="p-6 border-b border-white/5 bg-white/[0.02] flex justify-between items-center">
                <div>
                    <h3 class="text-lg font-semibold">Tabel Outranking & Ranking Dinamis</h3>
                    <p class="text-xs text-slate-400 mt-0.5">Skenario: <?php echo e($latestSimulasi->judul_skenario ?? 'Normal Skenario'); ?> &bull; Waktu: <?php echo e($latestSimulasi ? $latestSimulasi->created_at->format('d/m/Y H:i') : '-'); ?></p>
                </div>
                <span class="text-xs bg-indigo-500/20 text-indigo-300 px-3 py-1 rounded-full border border-indigo-500/20">ELECTRE Engine II</span>
            </div>
            <div class="overflow-x-auto">
                <table class="w-full text-left text-sm">
                    <thead class="border-b border-white/10 text-slate-400 bg-white/[0.01]">
                        <tr>
                            <th class="p-4 pl-6">Alternatif Kebijakan</th>
                            <?php $__currentLoopData = $periods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <th class="p-4 text-center">Net Score (<?php echo e($p); ?>)</th>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <th class="p-4 text-center">Total Net Score</th>
                            <th class="p-4 text-center">Status Rekomendasi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $alternatifs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
                            $totalScore = $accScores[$alt->kode] ?? 0;
                            $isTop = ($latestSimulasi && $latestSimulasi->rekomendasi_utama == $alt->nama);
                        ?>
                        <tr class="border-b border-white/5 hover:bg-indigo-500/5 transition-colors <?php echo e($isTop ? 'bg-indigo-500/10' : ''); ?>">
                            <td class="p-4 pl-6">
                                <p class="font-bold text-white"><?php echo e($alt->kode); ?> — <?php echo e($alt->nama); ?></p>
                                <p class="text-xs text-slate-400 mt-0.5"><?php echo e($alt->deskripsi); ?></p>
                            </td>
                            <?php $__currentLoopData = $periods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $score = $periodEvals[$p]['ranking'][$alt->kode] ?? ($periodEvals[$p]['netScores'][$alt->kode] ?? 0);
                                ?>
                                <td class="p-4 text-center">
                                    <span class="px-2.5 py-1 rounded font-mono text-xs font-semibold <?php echo e($score > 0 ? 'bg-emerald-500/20 text-emerald-300' : ($score < 0 ? 'bg-rose-500/20 text-rose-300' : 'bg-slate-700 text-slate-300')); ?>">
                                        <?php echo e($score > 0 ? '+'.$score : $score); ?>

                                    </span>
                                </td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <td class="p-4 text-center font-mono font-bold text-base <?php echo e($totalScore > 0 ? 'text-emerald-400' : 'text-slate-300'); ?>">
                                <?php echo e($totalScore > 0 ? '+'.$totalScore : $totalScore); ?>

                            </td>
                            <td class="p-4 text-center">
                                <?php if($isTop): ?>
                                    <span class="px-3 py-1 rounded-full text-xs font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40 inline-flex items-center gap-1.5 shadow-sm">
                                        <i class="fa-solid fa-crown text-[10px]"></i> Prioritas Utama
                                    </span>
                                <?php else: ?>
                                    <span class="text-xs text-slate-500">Alternatif Pendukung</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="p-6 text-center text-slate-400">Belum ada alternatif kebijakan tersimpan.</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        
        <div class="glass-card p-6">
            <h3 class="text-lg font-semibold mb-6 flex items-center gap-2">
                <i class="fa-solid fa-chart-column text-indigo-400"></i> Grafik Akumulasi Net Score Kebijakan
            </h3>
            <div style="height:300px;position:relative;">
                <canvas id="electreChart"></canvas>
            </div>
        </div>
    </main>

    <script>
        Chart.defaults.color = '#94a3b8';
        Chart.defaults.font.family = "'Outfit', sans-serif";

        const ctx = document.getElementById('electreChart').getContext('2d');
        const altLabels = <?php echo json_encode($alternatifs->pluck('kode')->toArray(), 15, 512) ?>;
        const accScoresData = <?php echo json_encode($accScores, 15, 512) ?>;

        const dataValues = altLabels.map(code => accScoresData[code] !== undefined ? accScoresData[code] : 0);

        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: altLabels,
                datasets: [{
                    label: 'Akumulasi Skor Outranking',
                    data: dataValues,
                    backgroundColor: dataValues.map(v => v > 0 ? '#6366f1' : '#475569'),
                    borderRadius: 8,
                    barPercentage: 0.5
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    y: {
                        grid: { color: 'rgba(255, 255, 255, 0.05)' },
                        ticks: { stepSize: 1 }
                    },
                    x: {
                        grid: { display: false }
                    }
                }
            }
        });
    </script>
</body>
</html>
<?php /**PATH D:\Laragon\www\dss-garam\resources\views/dynamic-electre.blade.php ENDPATH**/ ?>