
<!DOCTYPE html>
<html lang="id" class="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Dashboard DSS Garam Madura - Integrasi SD & ELECTRE</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    fontFamily: { sans: ['Outfit', 'sans-serif'] },
                    colors: {
                        brand: { 400: '#38bdf8', 500: '#0ea5e9', 600: '#0284c7' },
                        dark: { 800: '#1e293b', 900: '#0f172a' }
                    }
                }
            }
        }
    </script>
    <style>
        body {
            font-family: 'Outfit', sans-serif;
            background-color: #0f172a;
            color: #f8fafc;
            background-image: 
                radial-gradient(circle at 15% 50%, rgba(14, 165, 233, 0.08), transparent 25%),
                radial-gradient(circle at 85% 30%, rgba(99, 102, 241, 0.08), transparent 25%);
        }
        .glass-card {
            background: rgba(30, 41, 59, 0.6);
            backdrop-filter: blur(16px);
            border: 1px solid rgba(255, 255, 255, 0.05);
            border-radius: 1.25rem;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .glass-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 12px 30px -10px rgba(14, 165, 233, 0.15);
            border: 1px solid rgba(56, 189, 248, 0.3);
        }
        .gradient-text {
            background: linear-gradient(135deg, #38bdf8, #818cf8);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        .gradient-bg {
            background: linear-gradient(135deg, #0ea5e9, #6366f1);
        }
        ::-webkit-scrollbar { width: 6px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: #334155; border-radius: 4px; }
    </style>
</head>
<body class="flex h-screen overflow-hidden antialiased">

    
    <aside class="w-64 glass-card m-4 mr-2 flex flex-col justify-between hidden md:flex rounded-2xl relative z-10 overflow-hidden flex-shrink-0">
        <div class="absolute inset-0 bg-gradient-to-b from-sky-500/10 to-transparent opacity-50"></div>
        <div class="relative z-10">
            <div class="p-6 flex items-center gap-3 border-b border-white/5">
                <div class="w-10 h-10 rounded-xl gradient-bg flex items-center justify-center shadow-lg shadow-sky-500/30">
                    <i class="fa-solid fa-cube text-white text-lg"></i>
                </div>
                <div>
                    <h1 class="font-bold text-xl tracking-wide">SALT<span class="gradient-text">DSS</span></h1>
                    <p class="text-xs text-slate-400">Madura Analytics</p>
                </div>
            </div>
            <nav class="p-4 space-y-2 mt-4">
                <a href="<?php echo e(url('/')); ?>" class="flex items-center gap-3 px-4 py-3 rounded-xl bg-sky-500/10 text-sky-400 border border-sky-500/20 font-medium transition-all">
                    <i class="fa-solid fa-chart-line w-5 text-center"></i> Dashboard
                </a>
                <a href="<?php echo e(url('/system-dynamics')); ?>" class="flex items-center gap-3 px-4 py-3 rounded-xl text-slate-400 hover:text-white hover:bg-white/5 transition-all">
                    <i class="fa-solid fa-gears w-5 text-center"></i> System Dynamics
                </a>
                <a href="<?php echo e(url('/dynamic-electre')); ?>" class="flex items-center gap-3 px-4 py-3 rounded-xl text-slate-400 hover:text-white hover:bg-white/5 transition-all">
                    <i class="fa-solid fa-scale-balanced w-5 text-center"></i> Dynamic ELECTRE
                </a>
                <a href="<?php echo e(url('/expert-judgment')); ?>" class="flex items-center gap-3 px-4 py-3 rounded-xl text-slate-400 hover:text-white hover:bg-white/5 transition-all">
                    <i class="fa-solid fa-users-gear w-5 text-center"></i> Expert Judgment
                </a>
            </nav>
        </div>

        
        <div class="p-4 relative z-10 border-t border-white/5 space-y-3">
            <a href="<?php echo e(url('/laporan/cetak')); ?>" target="_blank" class="w-full flex items-center justify-center gap-2 p-2.5 rounded-xl bg-sky-600/20 hover:bg-sky-600/40 text-sky-300 text-xs font-semibold border border-sky-500/30 transition-all">
                <i class="fa-solid fa-print"></i> Cetak Laporan DSS
            </a>

            <?php if(auth()->guard()->check()): ?>
                <div class="p-3 rounded-xl bg-slate-800/60 border border-white/5 flex items-center justify-between">
                    <div class="flex items-center gap-2.5 overflow-hidden">
                        <img src="https://ui-avatars.com/api/?name=<?php echo e(urlencode(auth()->user()->name)); ?>&background=0ea5e9&color=fff" 
                             alt="Avatar" class="w-8 h-8 rounded-full border border-sky-400/30 flex-shrink-0">
                        <div class="truncate">
                            <p class="text-xs font-semibold text-white truncate"><?php echo e(auth()->user()->name); ?></p>
                            <p class="text-[10px] text-sky-400 capitalize"><?php echo e(auth()->user()->role ?? 'Admin'); ?></p>
                        </div>
                    </div>
                    <form action="<?php echo e(route('logout')); ?>" method="POST" class="m-0">
                        <?php echo csrf_field(); ?>
                        <button type="submit" title="Keluar / Logout" 
                                class="w-7 h-7 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 flex items-center justify-center transition-all">
                            <i class="fa-solid fa-power-off text-xs"></i>
                        </button>
                    </form>
                </div>
            <?php else: ?>
                <a href="<?php echo e(route('login')); ?>" 
                   class="w-full flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-gradient-to-r from-sky-500 to-indigo-600 hover:from-sky-600 hover:to-indigo-700 text-white text-xs font-semibold shadow-lg shadow-sky-500/20 transition-all">
                    <i class="fa-solid fa-arrow-right-to-bracket text-xs"></i>
                    <span>Masuk ke Akun</span>
                </a>
            <?php endif; ?>
        </div>
    </aside>

    
    <main class="flex-1 flex flex-col h-full relative overflow-y-auto overflow-x-hidden p-4 pl-2">
        <header class="flex justify-between items-center mb-8 px-2 mt-2">
            <div>
                <h2 class="text-2xl font-bold flex items-center gap-3">
                    <i class="fa-solid fa-chart-line text-sky-400"></i> Dashboard Rantai Pasok Garam
                </h2>
                <p class="text-sm text-slate-400 mt-1">Integrasi System Dynamics & Dynamic ELECTRE II Madura</p>
            </div>
            <div class="flex items-center gap-3">
                <a href="<?php echo e(url('/laporan/cetak')); ?>" target="_blank" class="glass-card px-4 py-2 text-xs font-semibold flex items-center gap-2 text-sky-300 hover:text-white transition-all">
                    <i class="fa-solid fa-file-pdf"></i> Ekspor PDF
                </a>
                <div class="glass-card px-4 py-2 text-xs flex items-center gap-2 text-sky-400">
                    <i class="fa-solid fa-database"></i> Database Aktif
                </div>
            </div>
        </header>

        
        <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <div class="glass-card p-6">
                <p class="text-slate-400 text-xs mb-1"><i class="fa-solid fa-crown text-amber-400 mr-2"></i>Rekomendasi Utama</p>
                <h3 class="text-lg font-bold text-sky-400 mt-1" id="label-rekomendasi">
                    <?php echo e($topPriority); ?>

                </h3>
                <p class="text-xs text-slate-500 mt-2">Peringkat 1 Skor Outranking</p>
            </div>

            <div class="glass-card p-6">
                <p class="text-slate-400 text-xs mb-1"><i class="fa-solid fa-boxes-stacked text-emerald-400 mr-2"></i>Kapasitas Gudang</p>
                <h3 class="text-2xl font-bold mt-1">50.000 <span class="text-xs font-normal text-slate-400">Ton</span></h3>
                <p class="text-xs text-emerald-400 mt-2"><i class="fa-solid fa-check mr-1"></i>Buffer Stock Aman</p>
            </div>

            <div class="glass-card p-6">
                <p class="text-slate-400 text-xs mb-1"><i class="fa-solid fa-layer-group text-purple-400 mr-2"></i>Kriteria Aktif</p>
                <h3 class="text-2xl font-bold mt-1"><?php echo e(count($kriterias)); ?> <span class="text-xs font-normal text-slate-400">Kriteria</span></h3>
                <p class="text-xs text-slate-500 mt-2">Tersinkron Database MySQL</p>
            </div>

            <div class="glass-card p-6">
                <p class="text-slate-400 text-xs mb-1"><i class="fa-solid fa-scale-balanced text-indigo-400 mr-2"></i>Alternatif Kebijakan</p>
                <h3 class="text-2xl font-bold mt-1"><?php echo e(count($alternatifs)); ?> <span class="text-xs font-normal text-slate-400">Alternatif</span></h3>
                <p class="text-xs text-slate-500 mt-2">Dianalisis secara Dinamis</p>
            </div>
        </div>

        
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
            
            <div class="glass-card p-6">
                <h3 class="text-base font-semibold mb-4 flex items-center gap-2">
                    <i class="fa-solid fa-play text-sky-400"></i> Eksekusi Simulasi
                </h3>
                <div class="space-y-4 text-xs">
                    <div>
                        <label class="block text-slate-400 mb-1">Nama Skenario</label>
                        <input type="text" id="skenario-nama" value="Skenario Kebijakan Prioritas 2026" 
                               class="w-full bg-slate-800/80 border border-white/10 rounded-xl px-3 py-2 text-white outline-none focus:border-sky-500">
                    </div>
                    <div>
                        <label class="block text-slate-400 mb-1">Curah Hujan (mm)</label>
                        <input type="number" id="skenario-hujan" value="120" 
                               class="w-full bg-slate-800/80 border border-white/10 rounded-xl px-3 py-2 text-white outline-none focus:border-sky-500">
                    </div>
                    <div>
                        <label class="block text-slate-400 mb-1">Kapasitas Buffer (Ton)</label>
                        <input type="number" id="skenario-gudang" value="50000" 
                               class="w-full bg-slate-800/80 border border-white/10 rounded-xl px-3 py-2 text-white outline-none focus:border-sky-500">
                    </div>
                    <button onclick="jalankanSimulasiDashboard()" id="btn-simulasi-dash"
                            class="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-sky-500 to-indigo-600 hover:from-sky-600 hover:to-indigo-700 font-semibold text-white transition-all shadow-lg shadow-sky-500/20 flex items-center justify-center gap-2">
                        <i id="icon-sim-dash" class="fa-solid fa-play"></i>
                        <span id="text-sim-dash">Jalankan Simulasi</span>
                    </button>
                </div>
            </div>

            
            <div class="lg:col-span-2 glass-card p-6">
                <h3 class="text-base font-semibold mb-4 flex items-center gap-2">
                    <i class="fa-solid fa-chart-column text-sky-400"></i> Skor Outranking Rekomendasi Terkini
                </h3>
                <div style="height: 240px; position: relative;">
                    <canvas id="dashboardChart"></canvas>
                </div>
            </div>
        </div>

        
        <div class="glass-card p-0 overflow-hidden mb-6">
            <div class="p-6 border-b border-white/5 bg-white/[0.02] flex justify-between items-center">
                <h3 class="text-base font-semibold">Riwayat Simulasi Terbaru (Tersimpan di MySQL)</h3>
                <a href="<?php echo e(url('/laporan/cetak')); ?>" target="_blank" class="text-xs text-sky-400 hover:underline">
                    Lihat Lembar Laporan &rarr;
                </a>
            </div>
            <div class="overflow-x-auto">
                <table class="w-full text-left text-xs">
                    <thead class="border-b border-white/10 text-slate-400 bg-white/[0.01]">
                        <tr>
                            <th class="p-4 pl-6">ID & Waktu</th>
                            <th class="p-4">Skenario</th>
                            <th class="p-4">Rekomendasi Terpilih</th>
                            <th class="p-4 text-center">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $riwayats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="border-b border-white/5 hover:bg-white/[0.02]">
                            <td class="p-4 pl-6 text-slate-400">#<?php echo e($r->id); ?> &bull; <?php echo e($r->created_at->diffForHumans()); ?></td>
                            <td class="p-4 font-medium text-white"><?php echo e($r->judul_skenario); ?></td>
                            <td class="p-4"><span class="px-2.5 py-1 rounded-full bg-sky-500/20 text-sky-300 font-semibold"><?php echo e($r->rekomendasi_utama); ?></span></td>
                            <td class="p-4 text-center">
                                <a href="<?php echo e(url('/laporan/cetak/' . $r->id)); ?>" target="_blank" class="px-3 py-1.5 rounded-lg bg-white/5 hover:bg-sky-500/20 text-sky-300 transition-all">
                                    <i class="fa-solid fa-print mr-1"></i> Cetak
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="4" class="p-6 text-center text-slate-500">Belum ada riwayat simulasi yang dijalankan.</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>

    <script>
        Chart.defaults.color = '#94a3b8';
        Chart.defaults.font.family = "'Outfit', sans-serif";

        const ctx = document.getElementById('dashboardChart').getContext('2d');
        <?php
            $defaultScores = ['A1' => 2, 'A2' => -2, 'A3' => 3, 'A4' => -1];
            $chartScores = ($latestSimulasi && isset($latestSimulasi->hasil_electre['accumulated_scores'])) 
                ? $latestSimulasi->hasil_electre['accumulated_scores'] 
                : $defaultScores;
        ?>
        const initialScores = <?php echo json_encode($chartScores); ?>;
        const labels = Object.keys(initialScores);
        const values = Object.values(initialScores);

        const chart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Net Score Outranking',
                    data: values,
                    backgroundColor: values.map(v => v > 0 ? '#38bdf8' : '#64748b'),
                    borderRadius: 6,
                    barPercentage: 0.5
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { display: false } },
                scales: {
                    y: { grid: { color: 'rgba(255,255,255,0.05)' } },
                    x: { grid: { display: false } }
                }
            }
        });

        async function jalankanSimulasiDashboard() {
            const skenario = document.getElementById('skenario-nama').value;
            const hujan = document.getElementById('skenario-hujan').value;
            const gudang = document.getElementById('skenario-gudang').value;
            const btn = document.getElementById('btn-simulasi-dash');
            const icon = document.getElementById('icon-sim-dash');
            const text = document.getElementById('text-sim-dash');

            btn.disabled = true;
            icon.className = 'fa-solid fa-spinner fa-spin';
            text.textContent = 'Memproses...';

            try {
                const res = await fetch('/simulasi', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
                        'Accept': 'application/json'
                    },
                    body: JSON.stringify({
                        skenario: skenario,
                        curah_hujan: hujan,
                        kapasitas_gudang: gudang
                    })
                });
                const data = await res.json();
                if(data.status === 'success') {
                    document.getElementById('label-rekomendasi').textContent = data.data.rekomendasi;
                    alert('Simulasi Berhasil!\nRekomendasi Utama: ' + data.data.rekomendasi);
                    setTimeout(() => location.reload(), 1000);
                }
            } catch(e) {
                alert('Gagal: ' + e.message);
            } finally {
                btn.disabled = false;
                icon.className = 'fa-solid fa-play';
                text.textContent = 'Jalankan Simulasi';
            }
        }
    </script>
</body>
</html>
<?php /**PATH D:\Laragon\www\dss-garam\resources\views/dashboard.blade.php ENDPATH**/ ?>