
<!DOCTYPE html>
<html lang="id" class="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>System Dynamics - DSS Garam Madura</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script>tailwind.config={darkMode:'class',theme:{extend:{fontFamily:{sans:['Outfit','sans-serif']},colors:{brand:{400:'#38bdf8',500:'#0ea5e9'},dark:{800:'#1e293b',900:'#0f172a'}}}}}</script>
    <style>
        body{font-family:'Outfit',sans-serif;background-color:#0f172a;color:#f8fafc;background-image:radial-gradient(circle at 15% 50%,rgba(14,165,233,.05),transparent 25%),radial-gradient(circle at 85% 30%,rgba(129,140,248,.05),transparent 25%)}
        .glass-card{background:rgba(30,41,59,.6);backdrop-filter:blur(16px);border:1px solid rgba(255,255,255,.05);border-radius:1.25rem;transition:all .3s}
        .glass-card:hover{transform:translateY(-2px);box-shadow:0 12px 30px -10px rgba(14,165,233,.15);border:1px solid rgba(56,189,248,.3)}
        .gradient-text{background:linear-gradient(135deg,#38bdf8,#818cf8);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
        .gradient-bg{background:linear-gradient(135deg,#0ea5e9,#6366f1)}
        ::-webkit-scrollbar{width:6px}::-webkit-scrollbar-track{background:transparent}::-webkit-scrollbar-thumb{background:#334155;border-radius:4px}
    </style>
</head>
<body class="flex h-screen overflow-hidden antialiased">

    
    <aside class="w-64 glass-card m-4 mr-2 flex flex-col justify-between hidden md:flex rounded-2xl relative z-10 overflow-hidden">
        <div class="absolute inset-0 bg-gradient-to-b from-blue-500/10 to-transparent opacity-50"></div>
        <div class="relative z-10">
            <div class="p-6 flex items-center gap-3 border-b border-white/5">
                <div class="w-10 h-10 rounded-xl gradient-bg flex items-center justify-center shadow-lg shadow-blue-500/30">
                    <i class="fa-solid fa-cube text-white text-lg"></i>
                </div>
                <div>
                    <h1 class="font-bold text-xl tracking-wide">SALT<span class="gradient-text">DSS</span></h1>
                    <p class="text-xs text-slate-400">Madura Analytics</p>
                </div>
            </div>
            <nav class="p-4 space-y-2 mt-4">
                <a href="<?php echo e(url('/')); ?>" class="flex items-center gap-3 px-4 py-3 rounded-xl text-slate-400 hover:text-white hover:bg-white/5 transition-all">
                    <i class="fa-solid fa-chart-line w-5 text-center"></i> Dashboard
                </a>
                <a href="<?php echo e(url('/system-dynamics')); ?>" class="flex items-center gap-3 px-4 py-3 rounded-xl bg-blue-500/10 text-blue-400 border border-blue-500/20 font-medium transition-all">
                    <i class="fa-solid fa-gears w-5 text-center"></i> System Dynamics
                </a>
                <a href="<?php echo e(url('/dynamic-electre')); ?>" class="flex items-center gap-3 px-4 py-3 rounded-xl text-slate-400 hover:text-white hover:bg-white/5 transition-all">
                    <i class="fa-solid fa-scale-balanced w-5 text-center"></i> Dynamic ELECTRE
                </a>
                <a href="<?php echo e(url('/expert-judgment')); ?>" class="flex items-center gap-3 px-4 py-3 rounded-xl text-slate-400 hover:text-white hover:bg-white/5 transition-all">
                    <i class="fa-solid fa-users-gear w-5 text-center"></i> Expert Judgment
                </a>
            </nav>
        </div>
        <div class="p-4 relative z-10 border-t border-white/5 space-y-3">
            <a href="<?php echo e(url('/laporan/cetak')); ?>" target="_blank" class="w-full flex items-center justify-center gap-2 p-2.5 rounded-xl bg-blue-600/20 hover:bg-blue-600/40 text-blue-300 text-xs font-semibold border border-blue-500/30 transition-all">
                <i class="fa-solid fa-print"></i> Cetak Laporan DSS
            </a>

            <?php if(auth()->guard()->check()): ?>
                <div class="p-3 rounded-xl bg-slate-800/60 border border-white/5 flex items-center justify-between">
                    <div class="flex items-center gap-2.5 overflow-hidden">
                        <img src="https://ui-avatars.com/api/?name=<?php echo e(urlencode(auth()->user()->name)); ?>&background=0ea5e9&color=fff" 
                             alt="Avatar" class="w-8 h-8 rounded-full border border-sky-400/30 flex-shrink-0">
                        <div class="truncate">
                            <p class="text-xs font-semibold text-white truncate"><?php echo e(auth()->user()->name); ?></p>
                            <p class="text-[10px] text-sky-400 capitalize"><?php echo e(auth()->user()->role ?? 'Admin'); ?></p>
                        </div>
                    </div>
                    <form action="<?php echo e(route('logout')); ?>" method="POST" class="m-0">
                        <?php echo csrf_field(); ?>
                        <button type="submit" title="Keluar / Logout" 
                                class="w-7 h-7 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 flex items-center justify-center transition-all">
                            <i class="fa-solid fa-power-off text-xs"></i>
                        </button>
                    </form>
                </div>
            <?php else: ?>
                <a href="<?php echo e(route('login')); ?>" 
                   class="w-full flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 text-white text-xs font-semibold shadow-lg shadow-blue-500/20 transition-all">
                    <i class="fa-solid fa-arrow-right-to-bracket text-xs"></i>
                    <span>Masuk ke Akun</span>
                </a>
            <?php endif; ?>
        </div>
    </aside>

    
    <main class="flex-1 flex flex-col h-full relative overflow-y-auto overflow-x-hidden p-4 pl-2">
        <header class="flex justify-between items-center mb-8 px-2 mt-2">
            <div>
                <h2 class="text-2xl font-bold flex items-center gap-3"><i class="fa-solid fa-gears text-blue-400"></i> Model System Dynamics</h2>
                <p class="text-sm text-slate-400 mt-1">Simulasi interaktif proyeksi produksi, stok cadangan, dan konsumsi garam</p>
            </div>
            <div class="flex items-center gap-3">
                <a href="<?php echo e(url('/laporan/cetak')); ?>" target="_blank" class="glass-card px-4 py-2 text-xs font-semibold flex items-center gap-2 text-blue-300 hover:text-white transition-all">
                    <i class="fa-solid fa-print"></i> Cetak Dokumen
                </a>
            </div>
        </header>

        
        <div class="glass-card p-6 mb-8">
            <h3 class="text-lg font-semibold mb-4 flex items-center gap-2">
                <i class="fa-solid fa-sliders text-blue-400"></i> Panel Eksperimen Skenario Kebijakan
            </h3>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div>
                    <label class="block text-xs text-slate-400 mb-2">Curah Hujan Rata-rata (mm/bulan)</label>
                    <input type="range" id="param-hujan" min="50" max="300" value="120" class="w-full accent-blue-500" oninput="simulasiLokal()">
                    <div class="flex justify-between text-xs text-slate-400 mt-1">
                        <span>Kering (50mm)</span>
                        <span id="label-hujan" class="font-bold text-blue-400 text-sm">120 mm</span>
                        <span>Basah (300mm)</span>
                    </div>
                </div>
                <div>
                    <label class="block text-xs text-slate-400 mb-2">Kapasitas Gudang Penyangga (Ton)</label>
                    <input type="range" id="param-gudang" min="20000" max="100000" step="5000" value="50000" class="w-full accent-blue-500" oninput="simulasiLokal()">
                    <div class="flex justify-between text-xs text-slate-400 mt-1">
                        <span>20.000 Ton</span>
                        <span id="label-gudang" class="font-bold text-blue-400 text-sm">50.000 Ton</span>
                        <span>100.000 Ton</span>
                    </div>
                </div>
                <div class="flex items-end">
                    <button onclick="kirimKeServer()" id="btn-simulasi" class="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 font-semibold text-white text-sm transition-all shadow-lg shadow-blue-500/20 flex items-center justify-center gap-2">
                        <i id="icon-sim" class="fa-solid fa-play"></i> Simpan Skenario ke Server
                    </button>
                </div>
            </div>
        </div>

        
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div class="glass-card p-6">
                <p class="text-slate-400 text-xs mb-1"><i class="fa-solid fa-seedling text-emerald-400 mr-2"></i>Produksi Garam Total</p>
                <h3 class="text-3xl font-bold" id="val-produksi">345,000 <span class="text-sm font-normal text-slate-400">Ton</span></h3>
                <p class="text-xs text-emerald-400 mt-2"><i class="fa-solid fa-circle-check mr-1"></i>Kondisi Surplus</p>
            </div>
            <div class="glass-card p-6">
                <p class="text-slate-400 text-xs mb-1"><i class="fa-solid fa-boxes-stacked text-amber-400 mr-2"></i>Cadangan Stok Akhir</p>
                <h3 class="text-3xl font-bold" id="val-stok">52,300 <span class="text-sm font-normal text-slate-400">Ton</span></h3>
                <p class="text-xs text-slate-500 mt-2">Daya tampung penyangga optimal</p>
            </div>
            <div class="glass-card p-6">
                <p class="text-slate-400 text-xs mb-1"><i class="fa-solid fa-truck-fast text-brand-400 mr-2"></i>Distribusi Logistik</p>
                <h3 class="text-3xl font-bold" id="val-distribusi">292,700 <span class="text-sm font-normal text-slate-400">Ton</span></h3>
                <p class="text-xs text-slate-500 mt-2">Terserap pasar konsumsi & industri</p>
            </div>
        </div>

        
        <div class="glass-card p-6 mb-8">
            <h3 class="text-lg font-semibold mb-4"><i class="fa-solid fa-chart-line text-blue-400 mr-2"></i>Grafik Dinamika Stok & Produksi (2026 - 2030)</h3>
            <div class="w-full" style="height:320px;position:relative;">
                <canvas id="sdChart"></canvas>
            </div>
        </div>
    </main>

    <script>
        Chart.defaults.color = '#94a3b8';
        Chart.defaults.font.family = "'Outfit', sans-serif";

        const ctx = document.getElementById('sdChart').getContext('2d');
        let myChart;

        function renderChart(prodData, stokData, distData) {
            if (myChart) myChart.destroy();
            myChart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: ['2026', '2027', '2028', '2029', '2030'],
                    datasets: [
                        {
                            label: 'Produksi (Ton)',
                            data: prodData,
                            borderColor: '#38bdf8',
                            backgroundColor: 'rgba(56, 189, 248, 0.1)',
                            fill: true,
                            tension: 0.4
                        },
                        {
                            label: 'Distribusi / Konsumsi (Ton)',
                            data: distData,
                            borderColor: '#818cf8',
                            borderDash: [5, 5],
                            tension: 0.4
                        },
                        {
                            label: 'Cadangan Stok (Ton)',
                            data: stokData,
                            borderColor: '#34d399',
                            backgroundColor: 'rgba(52, 211, 153, 0.1)',
                            fill: true,
                            tension: 0.4
                        }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: { legend: { position: 'top' } },
                    scales: {
                        y: { grid: { color: 'rgba(255, 255, 255, 0.05)' } },
                        x: { grid: { display: false } }
                    }
                }
            });
        }

        function simulasiLokal() {
            const hujan = parseFloat(document.getElementById('param-hujan').value);
            const gudang = parseFloat(document.getElementById('param-gudang').value);

            document.getElementById('label-hujan').textContent = hujan + ' mm';
            document.getElementById('label-gudang').textContent = gudang.toLocaleString('id-ID') + ' Ton';

            const faktor = Math.max(0.4, 1.3 - (hujan / 250));
            const prod = [
                Math.round(300000 * faktor),
                Math.round(320000 * faktor),
                Math.round(345000 * faktor),
                Math.round(360000 * faktor),
                Math.round(380000 * faktor)
            ];
            const dist = [270000, 280000, 292700, 310000, 325000];
            const stok = prod.map((p, i) => Math.min(gudang, Math.max(10000, p - dist[i] + 30000)));

            document.getElementById('val-produksi').innerHTML = prod[2].toLocaleString('id-ID') + ' <span class="text-sm font-normal text-slate-400">Ton</span>';
            document.getElementById('val-stok').innerHTML = stok[2].toLocaleString('id-ID') + ' <span class="text-sm font-normal text-slate-400">Ton</span>';
            document.getElementById('val-distribusi').innerHTML = dist[2].toLocaleString('id-ID') + ' <span class="text-sm font-normal text-slate-400">Ton</span>';

            renderChart(prod, stok, dist);
        }

        async function kirimKeServer() {
            const hujan = document.getElementById('param-hujan').value;
            const gudang = document.getElementById('param-gudang').value;
            const btn = document.getElementById('btn-simulasi');
            const icon = document.getElementById('icon-sim');

            btn.disabled = true;
            icon.className = 'fa-solid fa-spinner fa-spin';

            try {
                const res = await fetch('/simulasi', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
                        'Accept': 'application/json'
                    },
                    body: JSON.stringify({
                        skenario: `Uji Skenario Hujan ${hujan}mm - Kapasitas ${gudang} Ton`,
                        curah_hujan: hujan,
                        kapasitas_gudang: gudang
                    })
                });
                const data = await res.json();
                alert(data.message + '\nRekomendasi Terpilih: ' + data.data.rekomendasi);
            } catch (e) {
                alert('Gagal menjalankan simulasi: ' + e.message);
            } finally {
                btn.disabled = false;
                icon.className = 'fa-solid fa-play';
            }
        }

        // Jalankan kalkulasi awal saat halaman dibuka
        simulasiLokal();
    </script>
</body>
</html>
<?php /**PATH D:\Laragon\www\dss-garam\resources\views/system-dynamics.blade.php ENDPATH**/ ?>