<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\SimulationController;

// 1. Rute Terbuka (Login & Logout)
Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
Route::post('/login', [AuthController::class, 'login']);
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

// 2. Rute Tertutup (Wajib Login)
Route::middleware(['auth'])->group(function () {
    
    // Halaman Pakar (Bisa diakses Admin & Pakar)
    Route::get('/expert-judgment', [SimulationController::class, 'expertJudgment']);
    Route::post('/pakar/simpan', [SimulationController::class, 'simpanPenilaian']);

    // Halaman Dashboard & Simulasi (Khusus Admin / Pengambil Kebijakan)
    Route::get('/', [SimulationController::class, 'index']);
    Route::post('/simulasi', [SimulationController::class, 'jalankanSimulasi']);
    Route::get('/system-dynamics', [SimulationController::class, 'systemDynamics']);
    Route::get('/dynamic-electre', [SimulationController::class, 'dynamicElectre']);
    Route::get('/laporan/cetak/{id?}', [SimulationController::class, 'cetakLaporan']);
});
